<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>Educare</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body><header id="header1" class="blue-bg default-header">
    <div class="container">
        <div class="navbar-area flex space-between">
            <div class="left-bar">
                <div class="logo">
                    <a href="#">
                        <img src="img/logo/logo.png" alt="">
                    </a>
                </div>
            </div>
            <div class="right-bar flex">
                <nav>
                    <ul id="mobile" class="main-menu  hidden-xs">
                        <li class="my-active"><a href="#">Home</a>
                            <ul class="sub-menu">
                                <li><a href="index.php" target="_blank">Home University</a></li>
                                <li><a href="02-home-college.php" target="_blank">Home College</a></li>
                                <li><a href="03-home-online-education.php" target="_blank">Home Online Education</a></li>
                                <li><a href="04-home-language.php" target="_blank">Home Language</a></li>
                                <li><a href="05-home-kindergarten.php" target="_blank">Home Kindergarten</a></li>
                                <li><a href="06-home-driving-school.php" target="_blank">Home Driving School</a></li>
                                <li><a href="07-home-designing-school.php" target="_blank">Home Designing School</a></li>
                                <li><a href="08-home-cooking-school.php" target="_blank">Home Cooking School</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Courses</a>
                            <ul class="sub-menu">
                                <li><a href="10-course-grid-01.php" target="_blank">Course Grid 01</a></li>
                                <li><a href="11-course-grid-02.php" target="_blank">Course Grid 02</a></li>
                                <li><a href="12-course-list-01.php" target="_blank">Course List 01</a></li>
                                <li><a href="13-course-list-02.php" target="_blank">Course List 02</a></li>
                                <li><a href="14-course-details.php" target="_blank">Course Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Teacher</a>
                            <ul class="sub-menu">
                                <li><a href="26-teacher-grid.php" target="_blank">Teacher Grid</a></li>
                                <li><a href="27-teacher-list.php" target="_blank">Teacher List</a></li>
                                <li><a href="28-teacher-archive.php" target="_blank">Teacher Archive</a></li>
                                <li><a href="29-teacher-details.php" target="_blank">Teacher Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="32-blog-home.php" target="_blank">blog home</a></li>
                                <li><a href="33-blog-left-sidebar.php" target="_blank">blog Left sidebar</a></li>
                                <li><a href="34-blog-right-sidebar.php" target="_blank">blog right sidebar</a></li>
                                <li><a href="35-blog-single.php" target="_blank">blog single</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Events</a>
                            <ul class="sub-menu">
                                <li><a href="15-events-listview.php" target="_blank">Events list view</a></li>
                                <li><a href="16-events-gridview.php" target="_blank">Events grid view</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Shop</a>
                            <ul class="sub-menu">
                                <li><a href="36-shop-home.php" target="_blank">shop home</a></li>
                                <li><a href="37-shop-grid-sidebar.php" target="_blank">shop grid sidebar</a></li>
                                <li><a href="38-shop-list-sidebar.php" target="_blank">shop list sidebar</a></li>
                                <li><a href="39-shop-single-product.php" target="_blank">shop single product</a></li>
                                <li><a href="40-shop-cart.php" target="_blank">shop cart</a></li>
                                <li><a href="41-shop-checkout.php" target="_blank">shop checkout</a></li>
                                <li><a href="42-shop-payment.php" target="_blank">shop Payment</a></li>
                                <li><a href="43-shop-confirmation.php" target="_blank">shop Confirmation</a></li>
                            </ul>
                        </li>
                        <li><a href="#">buddypress</a>
                            <ul class="sub-menu">
                                <li><a href="44-buddypress-activity.php" target="_blank">Buddypress activity</a></li>
                                <li><a href="44-buddypress-activity-afterlogin.php" target="_blank">Buddypress activity afterLogin</a></li>
                                <li><a href="46-buddypress-members.php" target="_blank">Buddypress member</a></li>
                                <li><a href="45-buddypress-groups.php" target="_blank">Buddypress group</a></li>
                                <li><a href="48-buddypress-groupdetails-afterlogin.php" target="_blank">Buddypress group afterLogin</a></li>
                                <li><a href="49-buddypress-forums-home.php" target="_blank">Buddypress forums home</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="50-elements.php" target="_blank">Elements</a></li>
                                <li><a href="09-about.php" target="_blank">About Educare</a></li>
                                <li><a href="17-publication-board.php" target="_blank">publication board</a></li>
                                <li><a href="18-publication-details.php" target="_blank">publication details</a></li>
                                <li><a href="19-testimonials.php" target="_blank">testimonials</a></li>
                                <li><a href="20-clients.php" target="_blank">clients</a></li>
                                <li><a href="21-login-register.php" target="_blank">login / register</a></li>
                                <li><a href="22-department-grid.php" target="_blank">department grid</a></li>
                                <li><a href="23-department-list.php" target="_blank">depatment list</a></li>
                                <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                <li><a href="30-404-error.php" target="_blank">404 Error</a></li>
                                <li><a href="31-comming-soon.php" target="_blank">Comming soon</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <div class="cart">
                    <a href="#" class="icon"><i class="fa fa-shopping-basket" aria-hidden="true"></i></a>
                    <div class="mini-cart-wrapper">
                        <div class="cart-head text-right">
                            <h5>Your Cart :  <span>03</span></h5>
                        </div>
                        <div class="product-cart flex">
                            <div class="p-img">
                                <img src="img/shop/c1.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="desc">
                                <h5>Light Green tiffin Box <i class="fa fa-times" aria-hidden="true"></i></h5>
                                <p>1pc x <span>$250</span></p>
                            </div>
                        </div>
                        <div class="product-cart flex">
                            <div class="p-img">
                                <img src="img/shop/c2.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="desc">
                                <h5>Sky Blue Wate Bottle <i class="fa fa-times" aria-hidden="true"></i></h5>
                                <p>2pc x <span>$250</span></p>
                            </div>
                        </div>
                        <div class="product-cart flex">
                            <div class="p-img">
                                <img src="img/shop/c3.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="desc">
                                <h5>Light Pink School bag <i class="fa fa-times" aria-hidden="true"></i></h5>
                                <p>1pc x <span>$250</span></p>
                            </div>
                        </div>
                        <div class="total flex space-between">
                            <span>Subtotal</span><span>$1000.00</span>
                        </div>
                        <div class="fainal-cart">
                            <a href="#" class="btn">Go to Cart</a>
                        </div>
                    </div>
                </div>
                <div class="user">
                    <a href="#" class="icon"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
                </div>
                <div class="search-icon hidden-xs">
                    <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div>
<main>
<!-- Static Banner Area Start -->
<section id="slider" class="">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Shopping Cart</h2>
            <ul class="page-title-btn">
                <li><a href="01-home-university.php" target="_blank">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="36-shop-home.php" target="_blank">Shop <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Payment</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<!-- Shopping Cart Start -->
<div class="section-full">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="cart-topbar"></div>
                <div class="table-wrap">
                    <div class="total-table">
                        <div class="cart-table-head">
                            <ul class="flex">
                                <li><a href="40-shop-cart.php">Cart</a></li>
                                <li><a href="41-shop-checkout.php">Checkout</a></li>
                                <li><a href="42-shop-payment.php" class="active">Payment</a></li>
                            </ul>
                        </div>
                        <div class="checkout-body">
                            <div class="billing-info">
                                <div class="row">
                                    <div class="bill-field">
                                        <div class="col-sm-12">
                                            <div class="single-filter">
                                                <div class="select-ct">
                                                    <select>
                                                        <option value="1">Choose Your Card Type</option>
                                                        <option value="2">Master</option>
                                                        <option value="3">Visa</option>
                                                        <option value="4">Netler</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="single-filter">
                                                <input placeholder="Credit Card Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Credit Card Number'" type="text">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="single-filter">
                                                <input placeholder="Expiration Date" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Expiration Date'" type="text">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="single-filter">
                                                <input placeholder="Card CVV Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Card CVV Number'" type="text">
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="single-filter">
                                                <input placeholder="Card Holder Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Card Holder Name'" type="text">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="bottom-btn-group mt-20">
                                <a href="#" class="btn-proceed"> <i class="fa fa-caret-left"></i>Back to Checkout</a>
                                <a href="#" class="btn-proceed2">Place Order <i class="fa fa-caret-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Shopping Cart End -->
</main>
<!-- Footer Area Start -->
<footer id="footer1" class="bg-blue">
    <div class="footer2">
        <div class="container">
            <div class="row">
                <div class="footer-widget">
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-address">
                            <img src="img/footer/1.jpg" alt="" class="img-responsive">
                            <ul class="footer-address">
                                <li><span class="et-line icon-map-pin"></span>56/8, West panthapath,India.</li>
                                <li><span class="et-line icon-mic"></span> +00 91 234 567 890</li>
                                <li><span class="et-line icon-global"></span>www.educare.com</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-link">
                            <h4 class="second-title">Useful Links</h4>
                            <div class="row">
                                <div class="col-sm-4">
                                    <ul>
                                        <li><a href="09-about.php" target="_blank">About Us</a></li>
                                        <li><a href="32-blog-home.php" target="_blank">Blog</a></li>
                                        <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                        <li><a href="11-course-grid-02.php" target="_blank">Courses</a></li>
                                        <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                        <li><a href="15-events-listview.php" target="_blank">Events</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-8">
                                    <ul>
                                        <li><a href="#">Become a Teacher</a></li>
                                        <li><a href="#">Maintenance</a></li>
                                        <li><a href="#">Language Packs</a></li>
                                        <li><a href="#">LearnPress</a></li>
                                        <li><a href="#">Release Status</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-course">
                            <h4 class="second-title">Recent Courses</h4>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Graphic Design Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>20 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/3.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Adobe sketch Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank"> Adobe Indesign Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-contact">
                            <h4 class="second-title">Send Message</h4>
                            <form action="#">
                                <p><input placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" type="text" required></p>
                                <p><input placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" required></p>
                                <p><textarea cols="30" rows="10" placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" required></textarea></p>
                                <p><button class="btn submit-btn">Send</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="footer-social-link">
                        <ul class="flex flex-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-bottom-text">
                        <p>Copyright &amp;copy 2017. Designed by <a href="#">Codepixar Studio</a>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>
</html>