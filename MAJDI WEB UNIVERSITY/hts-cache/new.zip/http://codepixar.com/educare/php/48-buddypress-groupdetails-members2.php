<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>Educare</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body><header id="header1" class="blue-bg default-header">
    <div class="container">
        <div class="navbar-area flex space-between">
            <div class="left-bar">
                <div class="logo">
                    <a href="#">
                        <img src="img/logo/logo.png" alt="">
                    </a>
                </div>
            </div>
            <div class="right-bar flex">
                <nav>
                    <ul id="mobile" class="main-menu  hidden-xs">
                        <li class="my-active"><a href="#">Home</a>
                            <ul class="sub-menu">
                                <li><a href="index.php" target="_blank">Home University</a></li>
                                <li><a href="02-home-college.php" target="_blank">Home College</a></li>
                                <li><a href="03-home-online-education.php" target="_blank">Home Online Education</a></li>
                                <li><a href="04-home-language.php" target="_blank">Home Language</a></li>
                                <li><a href="05-home-kindergarten.php" target="_blank">Home Kindergarten</a></li>
                                <li><a href="06-home-driving-school.php" target="_blank">Home Driving School</a></li>
                                <li><a href="07-home-designing-school.php" target="_blank">Home Designing School</a></li>
                                <li><a href="08-home-cooking-school.php" target="_blank">Home Cooking School</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Courses</a>
                            <ul class="sub-menu">
                                <li><a href="10-course-grid-01.php" target="_blank">Course Grid 01</a></li>
                                <li><a href="11-course-grid-02.php" target="_blank">Course Grid 02</a></li>
                                <li><a href="12-course-list-01.php" target="_blank">Course List 01</a></li>
                                <li><a href="13-course-list-02.php" target="_blank">Course List 02</a></li>
                                <li><a href="14-course-details.php" target="_blank">Course Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Teacher</a>
                            <ul class="sub-menu">
                                <li><a href="26-teacher-grid.php" target="_blank">Teacher Grid</a></li>
                                <li><a href="27-teacher-list.php" target="_blank">Teacher List</a></li>
                                <li><a href="28-teacher-archive.php" target="_blank">Teacher Archive</a></li>
                                <li><a href="29-teacher-details.php" target="_blank">Teacher Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="32-blog-home.php" target="_blank">blog home</a></li>
                                <li><a href="33-blog-left-sidebar.php" target="_blank">blog Left sidebar</a></li>
                                <li><a href="34-blog-right-sidebar.php" target="_blank">blog right sidebar</a></li>
                                <li><a href="35-blog-single.php" target="_blank">blog single</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Events</a>
                            <ul class="sub-menu">
                                <li><a href="15-events-listview.php" target="_blank">Events list view</a></li>
                                <li><a href="16-events-gridview.php" target="_blank">Events grid view</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Shop</a>
                            <ul class="sub-menu">
                                <li><a href="36-shop-home.php" target="_blank">shop home</a></li>
                                <li><a href="37-shop-grid-sidebar.php" target="_blank">shop grid sidebar</a></li>
                                <li><a href="38-shop-list-sidebar.php" target="_blank">shop list sidebar</a></li>
                                <li><a href="39-shop-single-product.php" target="_blank">shop single product</a></li>
                                <li><a href="40-shop-cart.php" target="_blank">shop cart</a></li>
                                <li><a href="41-shop-checkout.php" target="_blank">shop checkout</a></li>
                                <li><a href="42-shop-payment.php" target="_blank">shop Payment</a></li>
                                <li><a href="43-shop-confirmation.php" target="_blank">shop Confirmation</a></li>
                            </ul>
                        </li>
                        <li><a href="#">buddypress</a>
                            <ul class="sub-menu">
                                <li><a href="44-buddypress-activity.php" target="_blank">Buddypress activity</a></li>
                                <li><a href="44-buddypress-activity-afterlogin.php" target="_blank">Buddypress activity afterLogin</a></li>
                                <li><a href="46-buddypress-members.php" target="_blank">Buddypress member</a></li>
                                <li><a href="45-buddypress-groups.php" target="_blank">Buddypress group</a></li>
                                <li><a href="48-buddypress-groupdetails-afterlogin.php" target="_blank">Buddypress group afterLogin</a></li>
                                <li><a href="49-buddypress-forums-home.php" target="_blank">Buddypress forums home</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="50-elements.php" target="_blank">Elements</a></li>
                                <li><a href="09-about.php" target="_blank">About Educare</a></li>
                                <li><a href="17-publication-board.php" target="_blank">publication board</a></li>
                                <li><a href="18-publication-details.php" target="_blank">publication details</a></li>
                                <li><a href="19-testimonials.php" target="_blank">testimonials</a></li>
                                <li><a href="20-clients.php" target="_blank">clients</a></li>
                                <li><a href="21-login-register.php" target="_blank">login / register</a></li>
                                <li><a href="22-department-grid.php" target="_blank">department grid</a></li>
                                <li><a href="23-department-list.php" target="_blank">depatment list</a></li>
                                <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                <li><a href="30-404-error.php" target="_blank">404 Error</a></li>
                                <li><a href="31-comming-soon.php" target="_blank">Comming soon</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <div class="search-icon hidden-xs">
                    <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Group Details</h2>
            <ul class="page-title-btn">
                <li><a href="#">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#">Buddypress<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Group Details</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<section class="section-full buddypress" id="buddypress">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="teacher-details member-top mb-50">
                    <div class="teacher-top flex">
                        <div class="teacher-img">
                            <img src="img/buddypress/c2.jpg" alt="" class="img-responsive">
                        </div>
                        <div class="teacher-top-content">
                            <h2>The Art of modern Graphics</h2>
                            <p>Public Group<span class="line">|</span>Active 2 year and 5 months ago.</p>
                            <a href="#" class="btn">Message</a>
                            <a href="#" class="btn">Join Group</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="event-filter buddypress-filter bd-filter-mb1 flex flex-wrap">
                    <div class="single-filter ft-107">
                        <a href="48-buddypress-groupdetails.php#buddypress" class="btn">Activity</a>
                    </div>
                    <div class="single-filter ft-98">
                        <a href="48-buddypress-groupdetails-forums2.php#buddypress" class="btn">Forums</a>
                    </div>
                    <div class="single-filter ft-117">
                        <a href="48-buddypress-groupdetails-members2.php#buddypress" class="btn active">Members (45)</a>
                    </div>
                    <div class="single-filter ft-107">
                        <a href="48-buddypress-groupdetails-admins2.php#buddypress" class="btn">Admins (05)</a>
                    </div>
                    <div class="single-filter ft-270">
                        <div class="select-ct">
                            <select>
                                <option value="1">Everything</option>
                                <option value="2">Updates</option>
                                <option value="3">Memberships</option>
                                <option value="4">Topics</option>
                                <option value="5">Replies</option>
                            </select>
                        </div>
                    </div>
                    <div class="single-filter ft-219">
                        <input placeholder="Enter Topic name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Topic name'" type="text">
                    </div>
                    <div class="single-filter ft-102">
                        <button class="btn">Search</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9 col-sm-8 col-xs-12">
                <div class="buddypress-activity group-activity member-activity">
                    <div class="total-status-post pt-10">
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/7.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Admin</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/8.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Angel_Princess</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Send Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/9.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Prince_Rebel</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/10.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Memphis_King</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/1.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Anubis_the_killer</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/11.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Trial_Prankz</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/12.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Troll_Boss</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/13.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Moana_Sea_Monster</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        <div class="single-status-post mt-20 flex flex-wrap space-between flex-middle">
                            <div class="member-info flex">
                                <div class="user-img">
                                    <a href="#"><img src="img/buddypress/14.jpg" alt=""></a>
                                </div>
                                <div class="user-post-details">
                                    <div class="name-details">
                                        <h4 class="name mt-10"><a href="#">Sea_Monster</a></h4>
                                    </div>
                                    <p>Active 2 years, 8 months ago</p>
                                </div>
                            </div>
                            <div class="member-request">
                                <a href="#">Cancel Friend Request</a>
                            </div>
                        </div>
                        
                        <div class="blog-pagination text-center mt-50">
                            <a href="#" class="btn prev"><i class="fa fa-caret-left"></i><span>Prev Page</span></a>
                            <a href="#">1</a>
                            <a href="#" class="active">2</a>
                            <a href="#">3</a>
                            <a href="#">4</a>
                            <a href="#">5</a>
                            <a href="#" class="btn next"><span>Next Page</span><i class="fa fa-caret-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-4 col-xs-12 buddypress-widget-total">
                <div class="single-widget pb-10">
                    <h2 class="main-head-event">Community</h2>
                    <div class="common-shadow community">
                        <ul>
                            <li><a href="#">Activity Stream</a></li>
                            <li><a href="#">Groups List</a></li>
                            <li><a href="#">Members List</a></li>
                            <li><a href="#">Forums</a></li>
                            <li><a href="#">Register</a></li>
                        </ul>
                    </div>
                </div>
                <div class="single-widget pb-10">
                    <h2 class="main-head-event">Member Sign in</h2>
                    <div class="common-shadow member-login event-filter">
                        <form action="#">
                            <div class="single-filter mb-10">
                                <input placeholder="Username" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Username'" type="text" required>
                            </div>
                            <div class="single-filter mb-10">
                                <input placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" type="password" required>
                            </div>
                            <div class="single-filter mb-10">
                                <button class="btn">Sign in</button>
                            </div>
                        </form>
                        <p class="forgot"><a href="#">Forgot Password?</a></p>
                        <p>Not a Member yot? <a href="#">Register</a></p>
                    </div>
                </div>
                <div class="single-widget pb-10">
                    <h2 class="main-head-event">Recent Posts</h2>
                    <div class="common-shadow community">
                        <ul>
                            <li><a href="#">You think light moves fast?</a></li>
                            <li><a href="#">Time travel did figure it out</a></li>
                            <li><a href="#">A matter of deductive Logic</a></li>
                            <li><a href="#">The Lysine Contingency</a></li>
                            <li><a href="#">You are the expert designer</a></li>
                        </ul>
                    </div>
                </div>
                <div class="single-widget pb-10">
                    <h2 class="main-head-event">Recent Comments</h2>
                    <div class="common-shadow recent-comments">
                        <ul>
                            <li>Billy T. on </li>
                            <li><a href="#">the Lysine contingency</a></li>
                            <li>admin on</li>
                            <li><a href="#">Aliquam dui</a></li>
                            <li>Sarah on</li>
                            <li><a href="#">ut Placerat Velit</a></li>
                            <li>admin on</li>
                            <li><a href="#">the lysine contingency</a></li>
                            <li>Norman on</li>
                            <li><a href="#">Mauris Lysine</a></li>
                            <li>admin on</li>
                            <li><a href="#">the lysine contingency</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</main>
<!-- Footer Area Start -->
<footer id="footer1" class="bg-blue">
    <div class="footer2">
        <div class="container">
            <div class="row">
                <div class="footer-widget">
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-address">
                            <img src="img/footer/1.jpg" alt="" class="img-responsive">
                            <ul class="footer-address">
                                <li><span class="et-line icon-map-pin"></span>56/8, West panthapath,India.</li>
                                <li><span class="et-line icon-mic"></span> +00 91 234 567 890</li>
                                <li><span class="et-line icon-global"></span>www.educare.com</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-link">
                            <h4 class="second-title">Useful Links</h4>
                            <div class="row">
                                <div class="col-sm-4">
                                    <ul>
                                        <li><a href="09-about.php" target="_blank">About Us</a></li>
                                        <li><a href="32-blog-home.php" target="_blank">Blog</a></li>
                                        <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                        <li><a href="11-course-grid-02.php" target="_blank">Courses</a></li>
                                        <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                        <li><a href="15-events-listview.php" target="_blank">Events</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-8">
                                    <ul>
                                        <li><a href="#">Become a Teacher</a></li>
                                        <li><a href="#">Maintenance</a></li>
                                        <li><a href="#">Language Packs</a></li>
                                        <li><a href="#">LearnPress</a></li>
                                        <li><a href="#">Release Status</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-course">
                            <h4 class="second-title">Recent Courses</h4>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Graphic Design Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>20 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/3.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Adobe sketch Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank"> Adobe Indesign Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-contact">
                            <h4 class="second-title">Send Message</h4>
                            <form action="#">
                                <p><input placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" type="text" required></p>
                                <p><input placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" required></p>
                                <p><textarea cols="30" rows="10" placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" required></textarea></p>
                                <p><button class="btn submit-btn">Send</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="footer-social-link">
                        <ul class="flex flex-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-bottom-text">
                        <p>Copyright &amp;copy 2017. Designed by <a href="#">Codepixar Studio</a>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>
</html>