<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>Educare</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body><header id="header1" class="blue-bg default-header">
    <div class="container">
        <div class="navbar-area flex space-between">
            <div class="left-bar">
                <div class="logo">
                    <a href="#">
                        <img src="img/logo/logo.png" alt="">
                    </a>
                </div>
            </div>
            <div class="right-bar flex">
                <nav>
                    <ul id="mobile" class="main-menu  hidden-xs">
                        <li class="my-active"><a href="#">Home</a>
                            <ul class="sub-menu">
                                <li><a href="index.php" target="_blank">Home University</a></li>
                                <li><a href="02-home-college.php" target="_blank">Home College</a></li>
                                <li><a href="03-home-online-education.php" target="_blank">Home Online Education</a></li>
                                <li><a href="04-home-language.php" target="_blank">Home Language</a></li>
                                <li><a href="05-home-kindergarten.php" target="_blank">Home Kindergarten</a></li>
                                <li><a href="06-home-driving-school.php" target="_blank">Home Driving School</a></li>
                                <li><a href="07-home-designing-school.php" target="_blank">Home Designing School</a></li>
                                <li><a href="08-home-cooking-school.php" target="_blank">Home Cooking School</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Courses</a>
                            <ul class="sub-menu">
                                <li><a href="10-course-grid-01.php" target="_blank">Course Grid 01</a></li>
                                <li><a href="11-course-grid-02.php" target="_blank">Course Grid 02</a></li>
                                <li><a href="12-course-list-01.php" target="_blank">Course List 01</a></li>
                                <li><a href="13-course-list-02.php" target="_blank">Course List 02</a></li>
                                <li><a href="14-course-details.php" target="_blank">Course Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Teacher</a>
                            <ul class="sub-menu">
                                <li><a href="26-teacher-grid.php" target="_blank">Teacher Grid</a></li>
                                <li><a href="27-teacher-list.php" target="_blank">Teacher List</a></li>
                                <li><a href="28-teacher-archive.php" target="_blank">Teacher Archive</a></li>
                                <li><a href="29-teacher-details.php" target="_blank">Teacher Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="32-blog-home.php" target="_blank">blog home</a></li>
                                <li><a href="33-blog-left-sidebar.php" target="_blank">blog Left sidebar</a></li>
                                <li><a href="34-blog-right-sidebar.php" target="_blank">blog right sidebar</a></li>
                                <li><a href="35-blog-single.php" target="_blank">blog single</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Events</a>
                            <ul class="sub-menu">
                                <li><a href="15-events-listview.php" target="_blank">Events list view</a></li>
                                <li><a href="16-events-gridview.php" target="_blank">Events grid view</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Shop</a>
                            <ul class="sub-menu">
                                <li><a href="36-shop-home.php" target="_blank">shop home</a></li>
                                <li><a href="37-shop-grid-sidebar.php" target="_blank">shop grid sidebar</a></li>
                                <li><a href="38-shop-list-sidebar.php" target="_blank">shop list sidebar</a></li>
                                <li><a href="39-shop-single-product.php" target="_blank">shop single product</a></li>
                                <li><a href="40-shop-cart.php" target="_blank">shop cart</a></li>
                                <li><a href="41-shop-checkout.php" target="_blank">shop checkout</a></li>
                                <li><a href="42-shop-payment.php" target="_blank">shop Payment</a></li>
                                <li><a href="43-shop-confirmation.php" target="_blank">shop Confirmation</a></li>
                            </ul>
                        </li>
                        <li><a href="#">buddypress</a>
                            <ul class="sub-menu">
                                <li><a href="44-buddypress-activity.php" target="_blank">Buddypress activity</a></li>
                                <li><a href="44-buddypress-activity-afterlogin.php" target="_blank">Buddypress activity afterLogin</a></li>
                                <li><a href="46-buddypress-members.php" target="_blank">Buddypress member</a></li>
                                <li><a href="45-buddypress-groups.php" target="_blank">Buddypress group</a></li>
                                <li><a href="48-buddypress-groupdetails-afterlogin.php" target="_blank">Buddypress group afterLogin</a></li>
                                <li><a href="49-buddypress-forums-home.php" target="_blank">Buddypress forums home</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="50-elements.php" target="_blank">Elements</a></li>
                                <li><a href="09-about.php" target="_blank">About Educare</a></li>
                                <li><a href="17-publication-board.php" target="_blank">publication board</a></li>
                                <li><a href="18-publication-details.php" target="_blank">publication details</a></li>
                                <li><a href="19-testimonials.php" target="_blank">testimonials</a></li>
                                <li><a href="20-clients.php" target="_blank">clients</a></li>
                                <li><a href="21-login-register.php" target="_blank">login / register</a></li>
                                <li><a href="22-department-grid.php" target="_blank">department grid</a></li>
                                <li><a href="23-department-list.php" target="_blank">depatment list</a></li>
                                <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                <li><a href="30-404-error.php" target="_blank">404 Error</a></li>
                                <li><a href="31-comming-soon.php" target="_blank">Comming soon</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <div class="search-icon hidden-xs">
                    <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Course Grid Style 02</h2>
            <ul class="page-title-btn">
                <li><a href="01-home-university.php" target="_blank">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Course Grid 02</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<!-- Regular Course Area Start -->
<section class="section-full course-grid1">
    <div class="container">
        <div class="popular-course">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head text-center pb-70">
                        <h2 class="first-title">Regular Courses</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adippisicing
                        elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="single-list-course row no-gutter">
                    <div class="col-xs-12 col-sm-4">
                        <img src="img/course/r1.jpg" alt="">
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="list-course-content">
                            <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                            <div class="course-bottom-list flex space-between">
                                <div class="single-bottom learn-b">
                                    <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                </div>
                                <div class="single-bottom icon">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="single-bottom review">
                                    <span>20 Reviews</span>
                                </div>
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom seats">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom dollar">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-list-course row no-gutter">
                    <div class="col-xs-12 col-sm-4">
                        <img src="img/course/r2.jpg" alt="">
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="list-course-content">
                            <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                            <div class="course-bottom-list flex space-between">
                                <div class="single-bottom learn-b">
                                    <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                </div>
                                <div class="single-bottom icon">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="single-bottom review">
                                    <span>20 Reviews</span>
                                </div>
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom seats">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom dollar">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-list-course row no-gutter">
                    <div class="col-xs-12 col-sm-4">
                        <img src="img/course/r3.jpg" alt="">
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="list-course-content">
                            <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                            <div class="course-bottom-list flex space-between">
                                <div class="single-bottom learn-b">
                                    <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                </div>
                                <div class="single-bottom icon">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="single-bottom review">
                                    <span>20 Reviews</span>
                                </div>
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom seats">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom dollar">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-list-course row no-gutter">
                    <div class="col-xs-12 col-sm-4">
                        <img src="img/course/r1.jpg" alt="">
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="list-course-content">
                            <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                            <div class="course-bottom-list flex space-between">
                                <div class="single-bottom learn-b">
                                    <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                </div>
                                <div class="single-bottom icon">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="single-bottom review">
                                    <span>20 Reviews</span>
                                </div>
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom seats">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom dollar">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-list-course row no-gutter">
                    <div class="col-xs-12 col-sm-4">
                        <img src="img/course/r2.jpg" alt="">
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="list-course-content">
                            <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                            <div class="course-bottom-list flex space-between">
                                <div class="single-bottom learn-b">
                                    <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                </div>
                                <div class="single-bottom icon">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="single-bottom review">
                                    <span>20 Reviews</span>
                                </div>
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom seats">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom dollar">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="load-content">
                    <div class="single-list-course row no-gutter">
                        <div class="col-xs-12 col-sm-4">
                            <img src="img/course/r3.jpg" alt="">
                        </div>
                        <div class="col-xs-12 col-sm-8">
                            <div class="list-course-content">
                                <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <div class="course-bottom-list flex space-between">
                                    <div class="single-bottom learn-b">
                                        <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                    </div>
                                    <div class="single-bottom icon">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="single-bottom review">
                                        <span>20 Reviews</span>
                                    </div>
                                    <div class="single-bottom trainer">
                                        <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                    </div>
                                    <div class="single-bottom seats">
                                        <span>Total 15 Seats</span>
                                    </div>
                                    <div class="single-bottom dollar">
                                        <span>$150</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-list-course row no-gutter">
                        <div class="col-xs-12 col-sm-4">
                            <img src="img/course/r1.jpg" alt="">
                        </div>
                        <div class="col-xs-12 col-sm-8">
                            <div class="list-course-content">
                                <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <div class="course-bottom-list flex space-between">
                                    <div class="single-bottom learn-b">
                                        <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                    </div>
                                    <div class="single-bottom icon">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="single-bottom review">
                                        <span>20 Reviews</span>
                                    </div>
                                    <div class="single-bottom trainer">
                                        <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                    </div>
                                    <div class="single-bottom seats">
                                        <span>Total 15 Seats</span>
                                    </div>
                                    <div class="single-bottom dollar">
                                        <span>$150</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="single-list-course row no-gutter">
                        <div class="col-xs-12 col-sm-4">
                            <img src="img/course/r2.jpg" alt="">
                        </div>
                        <div class="col-xs-12 col-sm-8">
                            <div class="list-course-content">
                                <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <div class="course-bottom-list flex space-between">
                                    <div class="single-bottom learn-b">
                                        <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                    </div>
                                    <div class="single-bottom icon">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="single-bottom review">
                                        <span>20 Reviews</span>
                                    </div>
                                    <div class="single-bottom trainer">
                                        <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                    </div>
                                    <div class="single-bottom seats">
                                        <span>Total 15 Seats</span>
                                    </div>
                                    <div class="single-bottom dollar">
                                        <span>$150</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 mt-60 text-center">
                <a href="#" class="btn load-course">View All Courses</a>
            </div>
        </div>
    </div>
</section>
<!-- / #Regular Course End -->
<!-- Col To Action Start -->
<section class="cta-1 cta2 ct3">
    <div class="cta-bg2 relative">
        <div class="overlay cta-overlay-bg-blue"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="cta-content">
                        <h2>Thousands of students are graduated. Why not you?</h2>
                        <form action="#" class="cta-register">
                            <div class="row">
                                <h3 class="text-center mb-40 primary-color fz-24">Register Now</h3>
                                <div class="col-md-offset-1 col-md-5 col-sm-6 col-xs-12">
                                    <p><input type="text"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" placeholder="Enter your Full Name"></p>
                                    <p><input type="email"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address'" placeholder="Enter your Full Name"></p>
                                </div>
                                <div class="col-md-5 col-sm-6 col-xs-12">
                                    <p><input type="text"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Phone Number'" placeholder="Enter your Full Name"></p>
                                    <div class="select-ct">
                                        <select>
                                            <option value="1">Choose course</option>
                                            <option value="2">Saab</option>
                                            <option value="3">Opel</option>
                                            <option value="4">Audi</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <p class="text-center"><button class="submit-btn">Submit</button></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Col To Action End -->
<!-- Core Features Area Start -->
<section class="section-full">
    <div class="container">
        <div class="core-feature">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head text-center pb-100">
                        <h2 class="first-title">Our Core Features</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adippisicing
                        elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="core-feature-body">
                <div class="col-sm-6">
                    <div class="row">
                        <div class="single-feature">
                            <div class="col-md-2 col-sm-3">
                                <div class="single-icon">
                                    <a href="#">
                                        <span class="et-line icon-heart text-black"></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-10 col-sm-9">
                                <div class="feture-content">
                                    <h4 class="media-heading"><a href="#">Quality Certification</a></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                    ad minim veniam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="single-feature">
                            <div class="col-md-2 col-sm-3">
                                <div class="single-icon">
                                    <a href="#">
                                        <span class="et-line icon-hotairballoon text-black mt-10"></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-10 col-sm-9">
                                <div class="feture-content">
                                    <h4 class="media-heading"><a href="#">Learning best practice</a></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                    ad minim veniam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="single-feature">
                            <div class="col-md-2 col-sm-3">
                                <div class="single-icon">
                                    <a href="#">
                                        <span class="et-line icon-telescope text-black mt-10"></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-10 col-sm-9">
                                <div class="feture-content">
                                    <h4 class="media-heading"><a href="#">Online Resources</a></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                    ad minim veniam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="row">
                        <div class="single-feature">
                            <div class="col-md-2 col-sm-3">
                                <div class="single-icon">
                                    <a href="#">
                                        <span class="et-line icon-search text-black mt-10"></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-10 col-sm-9">
                                <div class="feture-content">
                                    <h4 class="media-heading"><a href="#">Study plan tutors</a></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                    ad minim veniam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="single-feature">
                            <div class="col-md-2 col-sm-3">
                                <div class="single-icon">
                                    <a href="#">
                                        <span class="et-line icon-magnifying-glass text-black mt-10"></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-10 col-sm-9">
                                <div class="feture-content">
                                    <h4 class="media-heading"><a href="#">Advanced Practice</a></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                    ad minim veniam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="single-feature">
                            <div class="col-sm-3 col-md-2">
                                <div class="single-icon">
                                    <a href="#">
                                        <span class="et-line icon-puzzle text-black mt-10"></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-9 col-md-10">
                                <div class="feture-content">
                                    <h4 class="media-heading"><a href="#">Research</a></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                    ad minim veniam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / #Core Features End -->
</main>
<!-- Footer Area Start -->
<footer id="footer1" class="bg-blue">
    <div class="footer2">
        <div class="container">
            <div class="row">
                <div class="footer-widget">
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-address">
                            <img src="img/footer/1.jpg" alt="" class="img-responsive">
                            <ul class="footer-address">
                                <li><span class="et-line icon-map-pin"></span>56/8, West panthapath,India.</li>
                                <li><span class="et-line icon-mic"></span> +00 91 234 567 890</li>
                                <li><span class="et-line icon-global"></span>www.educare.com</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-link">
                            <h4 class="second-title">Useful Links</h4>
                            <div class="row">
                                <div class="col-sm-4">
                                    <ul>
                                        <li><a href="09-about.php" target="_blank">About Us</a></li>
                                        <li><a href="32-blog-home.php" target="_blank">Blog</a></li>
                                        <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                        <li><a href="11-course-grid-02.php" target="_blank">Courses</a></li>
                                        <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                        <li><a href="15-events-listview.php" target="_blank">Events</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-8">
                                    <ul>
                                        <li><a href="#">Become a Teacher</a></li>
                                        <li><a href="#">Maintenance</a></li>
                                        <li><a href="#">Language Packs</a></li>
                                        <li><a href="#">LearnPress</a></li>
                                        <li><a href="#">Release Status</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-course">
                            <h4 class="second-title">Recent Courses</h4>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Graphic Design Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>20 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/3.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Adobe sketch Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank"> Adobe Indesign Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-contact">
                            <h4 class="second-title">Send Message</h4>
                            <form action="#">
                                <p><input placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" type="text" required></p>
                                <p><input placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" required></p>
                                <p><textarea cols="30" rows="10" placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" required></textarea></p>
                                <p><button class="btn submit-btn">Send</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="footer-social-link">
                        <ul class="flex flex-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-bottom-text">
                        <p>Copyright &amp;copy 2017. Designed by <a href="#">Codepixar Studio</a>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>
</html>