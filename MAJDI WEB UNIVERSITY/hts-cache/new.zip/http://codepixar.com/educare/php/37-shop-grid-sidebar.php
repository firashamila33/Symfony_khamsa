<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>Educare</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body><header id="header1" class="blue-bg default-header">
    <div class="container">
        <div class="navbar-area flex space-between">
            <div class="left-bar">
                <div class="logo">
                    <a href="#">
                        <img src="img/logo/logo.png" alt="">
                    </a>
                </div>
            </div>
            <div class="right-bar flex">
                <nav>
                    <ul id="mobile" class="main-menu  hidden-xs">
                        <li class="my-active"><a href="#">Home</a>
                            <ul class="sub-menu">
                                <li><a href="index.php" target="_blank">Home University</a></li>
                                <li><a href="02-home-college.php" target="_blank">Home College</a></li>
                                <li><a href="03-home-online-education.php" target="_blank">Home Online Education</a></li>
                                <li><a href="04-home-language.php" target="_blank">Home Language</a></li>
                                <li><a href="05-home-kindergarten.php" target="_blank">Home Kindergarten</a></li>
                                <li><a href="06-home-driving-school.php" target="_blank">Home Driving School</a></li>
                                <li><a href="07-home-designing-school.php" target="_blank">Home Designing School</a></li>
                                <li><a href="08-home-cooking-school.php" target="_blank">Home Cooking School</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Courses</a>
                            <ul class="sub-menu">
                                <li><a href="10-course-grid-01.php" target="_blank">Course Grid 01</a></li>
                                <li><a href="11-course-grid-02.php" target="_blank">Course Grid 02</a></li>
                                <li><a href="12-course-list-01.php" target="_blank">Course List 01</a></li>
                                <li><a href="13-course-list-02.php" target="_blank">Course List 02</a></li>
                                <li><a href="14-course-details.php" target="_blank">Course Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Teacher</a>
                            <ul class="sub-menu">
                                <li><a href="26-teacher-grid.php" target="_blank">Teacher Grid</a></li>
                                <li><a href="27-teacher-list.php" target="_blank">Teacher List</a></li>
                                <li><a href="28-teacher-archive.php" target="_blank">Teacher Archive</a></li>
                                <li><a href="29-teacher-details.php" target="_blank">Teacher Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="32-blog-home.php" target="_blank">blog home</a></li>
                                <li><a href="33-blog-left-sidebar.php" target="_blank">blog Left sidebar</a></li>
                                <li><a href="34-blog-right-sidebar.php" target="_blank">blog right sidebar</a></li>
                                <li><a href="35-blog-single.php" target="_blank">blog single</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Events</a>
                            <ul class="sub-menu">
                                <li><a href="15-events-listview.php" target="_blank">Events list view</a></li>
                                <li><a href="16-events-gridview.php" target="_blank">Events grid view</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Shop</a>
                            <ul class="sub-menu">
                                <li><a href="36-shop-home.php" target="_blank">shop home</a></li>
                                <li><a href="37-shop-grid-sidebar.php" target="_blank">shop grid sidebar</a></li>
                                <li><a href="38-shop-list-sidebar.php" target="_blank">shop list sidebar</a></li>
                                <li><a href="39-shop-single-product.php" target="_blank">shop single product</a></li>
                                <li><a href="40-shop-cart.php" target="_blank">shop cart</a></li>
                                <li><a href="41-shop-checkout.php" target="_blank">shop checkout</a></li>
                                <li><a href="42-shop-payment.php" target="_blank">shop Payment</a></li>
                                <li><a href="43-shop-confirmation.php" target="_blank">shop Confirmation</a></li>
                            </ul>
                        </li>
                        <li><a href="#">buddypress</a>
                            <ul class="sub-menu">
                                <li><a href="44-buddypress-activity.php" target="_blank">Buddypress activity</a></li>
                                <li><a href="44-buddypress-activity-afterlogin.php" target="_blank">Buddypress activity afterLogin</a></li>
                                <li><a href="46-buddypress-members.php" target="_blank">Buddypress member</a></li>
                                <li><a href="45-buddypress-groups.php" target="_blank">Buddypress group</a></li>
                                <li><a href="48-buddypress-groupdetails-afterlogin.php" target="_blank">Buddypress group afterLogin</a></li>
                                <li><a href="49-buddypress-forums-home.php" target="_blank">Buddypress forums home</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="50-elements.php" target="_blank">Elements</a></li>
                                <li><a href="09-about.php" target="_blank">About Educare</a></li>
                                <li><a href="17-publication-board.php" target="_blank">publication board</a></li>
                                <li><a href="18-publication-details.php" target="_blank">publication details</a></li>
                                <li><a href="19-testimonials.php" target="_blank">testimonials</a></li>
                                <li><a href="20-clients.php" target="_blank">clients</a></li>
                                <li><a href="21-login-register.php" target="_blank">login / register</a></li>
                                <li><a href="22-department-grid.php" target="_blank">department grid</a></li>
                                <li><a href="23-department-list.php" target="_blank">depatment list</a></li>
                                <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                <li><a href="30-404-error.php" target="_blank">404 Error</a></li>
                                <li><a href="31-comming-soon.php" target="_blank">Comming soon</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <div class="cart">
                    <a href="#" class="icon"><i class="fa fa-shopping-basket" aria-hidden="true"></i></a>
                    <div class="mini-cart-wrapper">
                        <div class="cart-head text-right">
                            <h5>Your Cart :  <span>03</span></h5>
                        </div>
                        <div class="product-cart flex">
                            <div class="p-img">
                                <img src="img/shop/c1.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="desc">
                                <h5>Light Green tiffin Box <i class="fa fa-times" aria-hidden="true"></i></h5>
                                <p>1pc x <span>$250</span></p>
                            </div>
                        </div>
                        <div class="product-cart flex">
                            <div class="p-img">
                                <img src="img/shop/c2.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="desc">
                                <h5>Sky Blue Wate Bottle <i class="fa fa-times" aria-hidden="true"></i></h5>
                                <p>2pc x <span>$250</span></p>
                            </div>
                        </div>
                        <div class="product-cart flex">
                            <div class="p-img">
                                <img src="img/shop/c3.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="desc">
                                <h5>Light Pink School bag <i class="fa fa-times" aria-hidden="true"></i></h5>
                                <p>1pc x <span>$250</span></p>
                            </div>
                        </div>
                        <div class="total flex space-between">
                            <span>Subtotal</span><span>$1000.00</span>
                        </div>
                        <div class="fainal-cart">
                            <a href="#" class="btn">Go to Cart</a>
                        </div>
                    </div>
                </div>
                <div class="user">
                    <a href="#" class="icon"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
                </div>
                <div class="search-icon hidden-xs">
                    <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div>
<main>
<!-- Static Banner Area Start -->
<section id="slider" class="">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Product Grid with Sidebar</h2>
            <ul class="page-title-btn">
                <li><a href="01-home-university.php" target="_blank">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="36-shop-home.php" target="_blank">Shop<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Product Grid</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<section class="section-full blog-home blog-left-widget">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="event-filter flex">
                    <div class="single-filter ft-215">
                        <div class="select-ct">
                            <select>
                                <option value="1">Newest Products</option>
                                <option value="2">Trending Products</option>
                                <option value="3">Newest Products</option>
                                <option value="4">Oldest Products</option>
                                <option value="5">Best Sellers</option>
                                <option value="6">Best Rated</option>
                            </select>
                        </div>
                    </div>
                    <div class="single-filter ft-300">
                        <input placeholder="Enter Post title" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Post title'" type="text">
                    </div>
                    <div class="single-filter ft-175">
                        <div class="select-ct">
                            <select>
                                <option value="1">Education</option>
                                <option value="2">Men</option>
                                <option value="3">Shirts</option>
                                <option value="4">Pants</option>
                                <option value="5">Jackets</option>
                                <option value="6">Accessories</option>
                                <option value="7">Women</option>
                                <option value="4">Kids</option>
                            </select>
                        </div>
                    </div>
                    <div class="single-filter ft-135">
                        <button class="btn">Find Post</button>
                    </div>
                    <div class="single-filter ft-135 mr-n">
                        <a href="38-shop-list-sidebar.php" class="btn">List View</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9 col-sm-12">
                <!-- Product Area Start -->
                <div class="total-product mt-30">
                    <div class="row no-gutter">
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/1.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/2.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/3.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/4.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/5.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/6.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/7.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/8.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-product bg-gray">
                                <a href="39-shop-single-product.php" target="_blank">
                                    <figure>
                                        <img src="img/goods/9.png" alt="" class="img-responsive">
                                        <figcaption>
                                        <h6>Sears Headphones</h6>
                                        <ul class="flex space-between">
                                            <li class="primary-color">$250</li>
                                            <li><i class="fa fa-shopping-basket"></i></li>
                                        </ul>
                                        </figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        
                        <div class="row no-gutter load-content">
                            <div class="col-sm-4">
                                <div class="single-product bg-gray">
                                    <a href="39-shop-single-product.php" target="_blank">
                                        <figure>
                                            <img src="img/goods/4.png" alt="" class="img-responsive">
                                            <figcaption>
                                            <h6>Sears Headphones</h6>
                                            <ul class="flex space-between">
                                                <li class="primary-color">$250</li>
                                                <li><i class="fa fa-shopping-basket"></i></li>
                                            </ul>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="single-product bg-gray">
                                    <a href="39-shop-single-product.php" target="_blank">
                                        <figure>
                                            <img src="img/goods/5.png" alt="" class="img-responsive">
                                            <figcaption>
                                            <h6>Sears Headphones</h6>
                                            <ul class="flex space-between">
                                                <li class="primary-color">$250</li>
                                                <li><i class="fa fa-shopping-basket"></i></li>
                                            </ul>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="single-product bg-gray">
                                    <a href="39-shop-single-product.php" target="_blank">
                                        <figure>
                                            <img src="img/goods/6.png" alt="" class="img-responsive">
                                            <figcaption>
                                            <h6>Sears Headphones</h6>
                                            <ul class="flex space-between">
                                                <li class="primary-color">$250</li>
                                                <li><i class="fa fa-shopping-basket"></i></li>
                                            </ul>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="single-product bg-gray">
                                    <a href="39-shop-single-product.php" target="_blank">
                                        <figure>
                                            <img src="img/goods/7.png" alt="" class="img-responsive">
                                            <figcaption>
                                            <h6>Sears Headphones</h6>
                                            <ul class="flex space-between">
                                                <li class="primary-color">$250</li>
                                                <li><i class="fa fa-shopping-basket"></i></li>
                                            </ul>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="single-product bg-gray">
                                    <a href="39-shop-single-product.php" target="_blank">
                                        <figure>
                                            <img src="img/goods/8.png" alt="" class="img-responsive">
                                            <figcaption>
                                            <h6>Sears Headphones</h6>
                                            <ul class="flex space-between">
                                                <li class="primary-color">$250</li>
                                                <li><i class="fa fa-shopping-basket"></i></li>
                                            </ul>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="single-product bg-gray">
                                    <a href="39-shop-single-product.php" target="_blank">
                                        <figure>
                                            <img src="img/goods/9.png" alt="" class="img-responsive">
                                            <figcaption>
                                            <h6>Sears Headphones</h6>
                                            <ul class="flex space-between">
                                                <li class="primary-color">$250</li>
                                                <li><i class="fa fa-shopping-basket"></i></li>
                                            </ul>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 text-center mt-50">
                                <button class="btn load-course">load more</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Product Area End -->
                <div class="mt-150">
                    <div class="flex no-flex-xs women-headphone women-headphone2">
                        <div class="deal-left">
                            <img src="img/shop/s1.jpg" alt="" class="img-responsive">
                        </div>
                        <div class="deal-right">
                            <span class="top">Deal of the Day</span>
                            <h3>Mix Headphones for Women</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed doeiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <div class="total-box">
                                <div class="price">
                                    <h2>$935</h2>
                                    <span>$1000</span>
                                </div>
                            </div>
                            <div class="coutndown-area">
                                <div class="countdown flex space-between" id="js-countdown">
                                    <div class="countdown__item">
                                        <div class="countdown__timer js-countdown-days days common" aria-labelledby="day-countdown">

                                        </div>

                                        <div class="countdown__label title" id="day-countdown">Days</div>
                                    </div>

                                    <div class="countdown__item">
                                        <div class="countdown__timer hours common js-countdown-hours" aria-labelledby="hour-countdown">

                                        </div>

                                        <div class="countdown__label title" id="hour-countdown">Hours</div>
                                    </div>

                                    <div class="countdown__item">
                                        <div class="countdown__timer minutes common js-countdown-minutes" aria-labelledby="minute-countdown">

                                        </div>

                                        <div class="countdown__label title" id="minute-countdown">Minutes</div>
                                    </div>

                                    <div class="countdown__item">
                                        <div class="countdown__timer seconds common js-countdown-seconds" aria-labelledby="second-countdown">

                                        </div>

                                        <div class="countdown__label title" id="second-countdown">Seconds</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 <section class="pt-150 subscribe-field">
                    <div class="row">
                        <div class="col-sm-offset-1 col-sm-10 col-xs-12">
                            <h2>Subscribe to our Newsletter</h2>
                        </div>
                    </div>
                    <div class="row subscribe mt-30">
                        <div class="col-sm-offset-2 col-sm-8 flex no-flex-xs"><input placeholder="Enter Email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email address'" type="email"><button class="btn">Subscribe</button></div>
                    </div>
                    <div class="row text-center mt-30">
                        <p>Don’t worry, We won’t send any spam, promise</p>
                    </div>
                </section>
            </div>
            <div class="col-md-3 col-sm-12 shop-widget-total">
                <div class="single-widget pb-10">
                    <h2 class="main-head-event">Product Categories</h2>
                    <div class="common-shadow post-cat">
                        <ul>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">Men</a> <a role="button" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">09</a>
                                </div>
                                <ul class="sub-list collapse in" id="collapseExample">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample2" aria-expanded="false" aria-controls="collapseExample">Women</a> <a role="button" data-toggle="collapse" href="#collapseExample2" aria-expanded="false" aria-controls="collapseExample">09</a>
                                </div>
                                <ul class="sub-list collapse" id="collapseExample2">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample3" aria-expanded="false" aria-controls="collapseExample">Kids</a> <a role="button" data-toggle="collapse" href="#collapseExample3" aria-expanded="false" aria-controls="collapseExample">09</a>
                                </div>
                                <ul class="sub-list collapse" id="collapseExample3">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample4" aria-expanded="false" aria-controls="collapseExample">Electronics</a> <a role="button" data-toggle="collapse" href="#collapseExample4" aria-expanded="false" aria-controls="collapseExample">09</a>
                                </div>
                                <ul class="sub-list collapse" id="collapseExample4">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample5" aria-expanded="false" aria-controls="collapseExample">Home appliances</a> <a role="button" data-toggle="collapse" href="#collapseExample5" aria-expanded="false" aria-controls="collapseExample">09</a>
                                </div>
                                <ul class="sub-list collapse" id="collapseExample5">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample6" aria-expanded="false" aria-controls="collapseExample">Education</a> <a role="button" data-toggle="collapse" href="#collapseExample6" aria-expanded="false" aria-controls="collapseExample">09</a>
                                </div>
                                <ul class="sub-list collapse" id="collapseExample6">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample7" aria-expanded="false" aria-controls="collapseExample">Cooking</a> <a role="button" data-toggle="collapse" href="#collapseExample7" aria-expanded="false" aria-controls="collapseExample">07</a>
                                </div>
                                <ul class="sub-list collapse" id="collapseExample7">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                            <li class="first-li">
                                <div class="main-list flex space-between">
                                    <a role="button" data-toggle="collapse" href="#collapseExample8" aria-expanded="false" aria-controls="collapseExample">Driving</a> <a role="button" data-toggle="collapse" href="#collapseExample8" aria-expanded="false" aria-controls="collapseExample">06</a>
                                </div>
                                <ul class="sub-list collapse" id="collapseExample8">
                                    <li class="flex space-between"><a href="#">Shirts</a> <a href="#">11</a></li>
                                    <li class="flex space-between"><a href="#">Pants</a> <a href="#">07</a></li>
                                    <li class="flex space-between"><a href="#">Jackets</a> <a href="#">19</a></li>
                                    <li class="flex space-between"><a href="#">Blazers</a> <a href="#">03</a></li>
                                    <li class="flex space-between"><a href="#">Accessories</a> <a href="#">13</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="single-widget col-3 pb-10">
                    <h2 class="main-head-event">Recent Products</h2>
                    <div class="popular-post common-shadow shop-widget">
                        <div class="media">
                            <div class="media-left">
                                <a href="39-shop-single-product.php" target="_blank" class="post-img">
                                    <img src="img/shop/w1.jpg" alt="" class="media-object">
                                </a>
                            </div>
                            <div class="media-body">
                                <div class="media-heading"><a href="39-shop-single-product.php" target="_blank"><h4>Green tiffin Box</h4></a></div>
                                <span class="primary-color">$250</span>
                            </div>
                        </div>
                        <div class="media">
                            <div class="media-left">
                                <a href="39-shop-single-product.php" target="_blank" class="post-img">
                                    <img src="img/shop/w2.jpg" alt="" class="media-object">
                                </a>
                            </div>
                            <div class="media-body">
                                <div class="media-heading"><a href="39-shop-single-product.php" target="_blank"><h4>Blue Wate Bottle</h4></a></div>
                                <span class="primary-color">$250</span>
                            </div>
                        </div>
                        <div class="media">
                            <div class="media-left">
                                <a href="39-shop-single-product.php" target="_blank" class="post-img">
                                    <img src="img/shop/w3.jpg" alt="" class="media-object">
                                </a>
                            </div>
                            <div class="media-body">
                                <div class="media-heading"><a href="39-shop-single-product.php" target="_blank"><h4>Pink School bag</h4></a></div>
                                <span class="primary-color">$250</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="single-widget pb-10">
                    <h2 class="main-head-event">Post Archive</h2>
                    <div class="common-shadow post-arc flex">
                        <ul class="year">
                            <li><a href="#">2017</a></li>
                            <li><a href="#">2016</a></li>
                            <li><a href="#">2015</a></li>
                            <li><a href="#">2014</a></li>
                            <li><a href="#">2013</a></li>
                            <li><a href="#">2012</a></li>
                        </ul>
                        <ul class="month">
                            <li><a href="#">December</a></li>
                            <li><a href="#">November</a></li>
                            <li><a href="#">October</a></li>
                            <li><a href="#">September</a></li>
                            <li><a href="#">August</a></li>
                            <li><a href="#">July</a></li>
                            <li><a href="#">June</a></li>
                            <li><a href="#">May</a></li>
                            <li><a href="#">April</a></li>
                            <li><a href="#">March</a></li>
                            <li><a href="#">February</a></li>
                            <li><a href="#">January</a></li>
                        </ul>
                    </div>
                </div>
                <div class="single-widget col-3 pb-10">
                    <h2 class="main-head-event">Tag Cloud</h2>
                    <ul class="widget-keywords">
                        <li><a href="#">Designing,</a></li>
                        <li><a href="#">Photoshop,</a></li>
                        <li><a class="big" href="#">Illustrator,</a></li>
                        <li><a href="#">Graphic Design,</a></li>
                        <li><a class="big" href="#">Education,</a></li>
                        <li><a href="#">Online,</a></li>
                        <li><a href="#">Online Education,</a></li>
                        <li><a href="#">Driving,</a></li>
                        <li><a href="#">Cooking,</a></li>
                        <li><a href="#">School,</a></li>
                        <li><a href="#">College,</a></li>
                        <li><a class="big" href="#">University,</a></li>
                        <li><a href="#">Kindergaarten</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
</main>
<!-- Footer Area Start -->
<footer id="footer1" class="bg-blue">
    <div class="footer2">
        <div class="container">
            <div class="row">
                <div class="footer-widget">
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-address">
                            <img src="img/footer/1.jpg" alt="" class="img-responsive">
                            <ul class="footer-address">
                                <li><span class="et-line icon-map-pin"></span>56/8, West panthapath,India.</li>
                                <li><span class="et-line icon-mic"></span> +00 91 234 567 890</li>
                                <li><span class="et-line icon-global"></span>www.educare.com</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-link">
                            <h4 class="second-title">Useful Links</h4>
                            <div class="row">
                                <div class="col-sm-4">
                                    <ul>
                                        <li><a href="09-about.php" target="_blank">About Us</a></li>
                                        <li><a href="32-blog-home.php" target="_blank">Blog</a></li>
                                        <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                        <li><a href="11-course-grid-02.php" target="_blank">Courses</a></li>
                                        <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                        <li><a href="15-events-listview.php" target="_blank">Events</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-8">
                                    <ul>
                                        <li><a href="#">Become a Teacher</a></li>
                                        <li><a href="#">Maintenance</a></li>
                                        <li><a href="#">Language Packs</a></li>
                                        <li><a href="#">LearnPress</a></li>
                                        <li><a href="#">Release Status</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-course">
                            <h4 class="second-title">Recent Courses</h4>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Graphic Design Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>20 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/3.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Adobe sketch Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/2.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank"> Adobe Indesign Course</a></h4>
                                    <p class="reviews">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <span>35 Reviews</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-contact">
                            <h4 class="second-title">Send Message</h4>
                            <form action="#">
                                <p><input placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" type="text" required></p>
                                <p><input placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" required></p>
                                <p><textarea cols="30" rows="10" placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" required></textarea></p>
                                <p><button class="btn submit-btn">Send</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="footer-social-link">
                        <ul class="flex flex-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-bottom-text">
                        <p>Copyright &amp;copy 2017. Designed by <a href="#">Codepixar Studio</a>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>
</html>