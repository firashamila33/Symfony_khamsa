<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>Educare</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body><main class="kindergarten">
<header id="header5" class="white-bg k-header-top default-header">
    <div class="header-top hidden-xs">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-sm-6 col-xs-12 top-left">
                    <ul class="flex no-flex-xs">
                        <li><i class="fa fa-clock-o"></i> Mon to fri 08.00am - 2pm</li>
                        <li class="email"><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:info@educare.com">info@educare.com</a></li>
                    </ul>
                </div>
                <div class="col-md-offset-3 col-md-4 col-sm-6 col-xs-12 top-right">
                    <ul class="flex flex-right">
                        <li class="phone"><i class="fa fa-phone" aria-hidden="true"></i><a href="tel:+1386-263-3623">+1386-263-3623</a></li>
                        <li class="flex select-icon">
                            <i class="fa fa-language" aria-hidden="true"></i>
                            <div class="">
                                <div class="select-ct">
                                    <select>
                                        <option value="1">English</option>
                                        <option value="2">Bangla</option>
                                        <option value="3">Hindi</option>
                                        <option value="4">Chinese</option>
                                    </select>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="navbar-area kindergarten-nav flex space-between">
            <div class="left-bar">
                <div class="logo">
                    <a href="#">
                        <img src="img/kindergarten/logo.png" alt="">
                    </a>
                </div>
            </div>
            <div class="right-bar flex">
                <nav>
                    <ul id="mobile" class="main-menu  hidden-xs">
                        <li class="my-active"><a href="#">Home</a>
                            <ul class="sub-menu">
                                <li><a href="index.php" target="_blank">Home University</a></li>
                                <li><a href="02-home-college.php" target="_blank">Home College</a></li>
                                <li><a href="03-home-online-education.php" target="_blank">Home Online Education</a></li>
                                <li><a href="04-home-language.php" target="_blank">Home Language</a></li>
                                <li><a href="05-home-kindergarten.php" target="_blank">Home Kindergarten</a></li>
                                <li><a href="06-home-driving-school.php" target="_blank">Home Driving School</a></li>
                                <li><a href="07-home-designing-school.php" target="_blank">Home Designing School</a></li>
                                <li><a href="08-home-cooking-school.php" target="_blank">Home Cooking School</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Courses</a>
                            <ul class="sub-menu">
                                <li><a href="10-course-grid-01.php" target="_blank">Course Grid 01</a></li>
                                <li><a href="11-course-grid-02.php" target="_blank">Course Grid 02</a></li>
                                <li><a href="12-course-list-01.php" target="_blank">Course List 01</a></li>
                                <li><a href="13-course-list-02.php" target="_blank">Course List 02</a></li>
                                <li><a href="14-course-details.php" target="_blank">Course Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Teacher</a>
                            <ul class="sub-menu">
                                <li><a href="26-teacher-grid.php" target="_blank">Teacher Grid</a></li>
                                <li><a href="27-teacher-list.php" target="_blank">Teacher List</a></li>
                                <li><a href="28-teacher-archive.php" target="_blank">Teacher Archive</a></li>
                                <li><a href="29-teacher-details.php" target="_blank">Teacher Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="32-blog-home.php" target="_blank">blog home</a></li>
                                <li><a href="33-blog-left-sidebar.php" target="_blank">blog Left sidebar</a></li>
                                <li><a href="34-blog-right-sidebar.php" target="_blank">blog right sidebar</a></li>
                                <li><a href="35-blog-single.php" target="_blank">blog single</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Events</a>
                            <ul class="sub-menu">
                                <li><a href="15-events-listview.php" target="_blank">Events list view</a></li>
                                <li><a href="16-events-gridview.php" target="_blank">Events grid view</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Shop</a>
                            <ul class="sub-menu">
                                <li><a href="36-shop-home.php" target="_blank">shop home</a></li>
                                <li><a href="37-shop-grid-sidebar.php" target="_blank">shop grid sidebar</a></li>
                                <li><a href="38-shop-list-sidebar.php" target="_blank">shop list sidebar</a></li>
                                <li><a href="39-shop-single-product.php" target="_blank">shop single product</a></li>
                                <li><a href="40-shop-cart.php" target="_blank">shop cart</a></li>
                                <li><a href="41-shop-checkout.php" target="_blank">shop checkout</a></li>
                                <li><a href="42-shop-payment.php" target="_blank">shop Payment</a></li>
                                <li><a href="43-shop-confirmation.php" target="_blank">shop Confirmation</a></li>
                            </ul>
                        </li>
                        <li><a href="#">buddypress</a>
                            <ul class="sub-menu">
                                <li><a href="44-buddypress-activity.php" target="_blank">Buddypress activity</a></li>
                                <li><a href="44-buddypress-activity-afterlogin.php" target="_blank">Buddypress activity afterLogin</a></li>
                                <li><a href="46-buddypress-members.php" target="_blank">Buddypress member</a></li>
                                <li><a href="45-buddypress-groups.php" target="_blank">Buddypress group</a></li>
                                <li><a href="48-buddypress-groupdetails-afterlogin.php" target="_blank">Buddypress group afterLogin</a></li>
                                <li><a href="49-buddypress-forums-home.php" target="_blank">Buddypress forums home</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="50-elements.php" target="_blank">Elements</a></li>
                                <li><a href="09-about.php" target="_blank">About Educare</a></li>
                                <li><a href="17-publication-board.php" target="_blank">publication board</a></li>
                                <li><a href="18-publication-details.php" target="_blank">publication details</a></li>
                                <li><a href="19-testimonials.php" target="_blank">testimonials</a></li>
                                <li><a href="20-clients.php" target="_blank">clients</a></li>
                                <li><a href="21-login-register.php" target="_blank">login / register</a></li>
                                <li><a href="22-department-grid.php" target="_blank">department grid</a></li>
                                <li><a href="23-department-list.php" target="_blank">depatment list</a></li>
                                <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                <li><a href="30-404-error.php" target="_blank">404 Error</a></li>
                                <li><a href="31-comming-soon.php" target="_blank">Comming soon</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <div class="search-icon hidden-xs">
                    <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><section id="slider" class="slider-section relative">
    <div class="slider1 deafult-slider kindergarten-slider">
        <div class="item relative  fitscreen flex flex-middle" style="background: url(img/kindergarten/s1.jpg);">
            <div class="overlay content-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-10 col-xs-12">
                        <div class="slide-content">
                            <h1>Devoted to the early education</h1>
                            <p class="light ">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="10-course-grid-01.php" target="_blank" class="btn btn1 mt-10 mr-10">Start Now</a>
                            <a href="09-about.php" target="_blank" class="btn btn2 mt-10">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item relative  fitscreen flex flex-middle" style="background: url(img/kindergarten/s2.jpg); background-position: center right;">
            <div class="overlay content-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-10 col-xs-12">
                        <div class="slide-content">
                            <h1>Early education builds broadness</h1>
                            <p class="light ">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="10-course-grid-01.php" target="_blank" class="btn btn1 mt-10 mr-10">Start Now</a>
                            <a href="09-about.php" target="_blank" class="btn btn2 mt-10">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Kindergarten Special Start -->
<section class="section-full">
    <div class="container">
        <div class="educare-special">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head s-head1 text-center pb-100">
                        <h2 class="first-title">educare specialities</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adippisicingelit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="total-special">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-special">
                            <div class="special-img">
                                <img src="img/kindergarten/e1.jpg" alt="" class="img-responsive">
                            </div>
                            <h3><a href="#">Learning & Fun</a></h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit, seddo eiusmod temp orincid.</p>
                            <div class="sp-corner1">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                            <div class="sp-corner2">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-special special2">
                            <div class="special-img">
                                <img src="img/kindergarten/e1.jpg" alt="" class="img-responsive">
                            </div>
                            <h3><a href="#">Healthy Meal</a></h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit, seddo eiusmod temp orincid.</p>
                            <div class="sp-corner1">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                            <div class="sp-corner2">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-special special3">
                            <div class="special-img">
                                <img src="img/kindergarten/e1.jpg" alt="" class="img-responsive">
                            </div>
                            <h3><a href="">Children Safety</a></h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit, seddo eiusmod temp orincid.</p>
                            <div class="sp-corner1">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                            <div class="sp-corner2">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="single-special special4">
                            <div class="special-img">
                                <img src="img/kindergarten/e1.jpg" alt="" class="img-responsive">
                            </div>
                            <h3><a href="#">Cute Environment</a></h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit, seddo eiusmod temp orincid.</p>
                            <div class="sp-corner1">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                            <div class="sp-corner2">
                                <div class="mini-corner1"></div>
                                <div class="mini-corner2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Kindergarten Special Start -->
<!-- Kindergarten Special Start -->
<section class="section-full special-programs relative">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8 col-sm-12">
                <div class="section-head s-head1 text-center pb-100">
                    <h2 class="first-title">Educare special programs</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adippisicingelit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="total-programs">
                <div class="col-md-4 col-sm-6">
                    <div class="single-program flex">
                        <div class="icon">
                            <span class="i1 flaticon-baby-stroller"></span>
                        </div>
                        <div class="program-body">
                            <h4 class="ph1"><a href="14-course-details.php" target="_blank">Toddler (1,5 – 2 years)</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-program flex">
                        <div class="icon">
                            <span class="i2 flaticon-abacus"></span>
                        </div>
                        <div class="program-body">
                            <h4 class="ph2"><a href="14-course-details.php" target="_blank">Preschool (2 – 3 years)</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-program flex">
                        <div class="icon">
                            <span class="i3 flaticon-bicycle"></span>
                        </div>
                        <div class="program-body">
                            <h4 class="ph3"><a href="14-course-details.php" target="_blank">Kindergarten (3 – 4 years)</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-program flex">
                        <div class="icon">
                            <span class="i4 flaticon-car"></span>
                        </div>
                        <div class="program-body">
                            <h4 class="ph4"><a href="14-course-details.php" target="_blank">Pre-K Program (4 – 5 years)</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-program flex">
                        <div class="icon">
                            <span class="i5 flaticon-kite"></span>
                        </div>
                        <div class="program-body">
                            <h4 class="ph5"><a href="14-course-details.php" target="_blank">Before/After School (6 years)</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-program flex">
                        <div class="icon">
                            <span class="i6 flaticon-swing"></span>
                        </div>
                        <div class="program-body">
                            <h4 class="ph6"><a href="14-course-details.php" target="_blank">Outdoor Play Time</a></h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 text-center">
                    <a href="11-course-grid-02.php" target="_blank" class="btn">View All Courses</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Kindergarten Special Start -->
<!-- Regular Class Area Start -->
<section class="regular-classes section-full">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8 col-sm-12">
                <div class="section-head s-head1 text-center pb-100">
                    <h2 class="first-title">Regular Classes</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adippisicingelit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="total-classes">
                <div class="col-sm-4">
                    <div class="single-classes first-class">
                        <div class="class-img relative">
                            <img src="img/kindergarten/c1.jpg" alt="" class="img-responsive">
                            <div class="overlay overlay-bg"></div>
                        </div>
                        <div class="class-content">
                            <h3><a href="#">Letter Matching Class</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporincididunt ut labore et dolore aliqua. </p>
                            <ul>
                                <li>4-5 Years of age</li>
                                <li>10 Seats</li>
                                <li>$20/Day</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="single-classes second-class">
                        <div class="class-img relative">
                            <img src="img/kindergarten/c2.jpg" alt="" class="img-responsive">
                            <div class="overlay overlay-bg"></div>
                        </div>
                        <div class="class-content">
                            <h3><a href="#">Drawing & Painting Class</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporincididunt ut labore et dolore aliqua. </p>
                            <ul>
                                <li>4-5 Years of age</li>
                                <li>10 Seats</li>
                                <li>$20/Day</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="single-classes third-class">
                        <div class="class-img relative">
                            <img src="img/kindergarten/c3.jpg" alt="" class="img-responsive">
                            <div class="overlay overlay-bg"></div>
                        </div>
                        <div class="class-content">
                            <h3><a href="#">Drawing & Painting Class</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporincididunt ut labore et dolore aliqua. </p>
                            <ul>
                                <li>4-5 Years of age</li>
                                <li>10 Seats</li>
                                <li>$20/Day</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / #Regular Class Area End  -->
<!-- Chairman Msg Start -->
<section id="chair-msg" class="relative kindergarten-principal chair-msg">
    <div class="chairman-bg">
        <div class="overlay test-overlay-bg"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-7">
                    <div class="chairman-text">
                        <h2 class="first-title">Words from Principal</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adip pisicing elit, sed do eiusmod tempor incididunt ut labore et dolore  magna aliqua. Ut enim ad minim veniam, quis nostrud exercitationullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute iru lor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                        <img src="img/chairman/s2.png" alt="" class="sign img-responsive">
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="chairman-img">
                        <img src="img/chairman/chancellor.png" alt="" class="img-responsive">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Chairman Msg End -->
<!-- Notice Board Start -->
<section class="section-full bg-gray kindergarten-notice">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-offset-10">
                <div class="section-head text-center pb-100">
                    <h2 class="first-title">Notice Board</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adippisicing
                    elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="total-notice">
                <div class="col-sm-6 col-xs-12">
                    <div class="single-notice notice1">
                        <h3><a href="18-publication-details.php" target="_blank">New intake</a></h3>
                        <p class="credit">By <span>Lara croft</span>, Jan 21st 2017</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                        <div class="notice-comment flex space-between">
                            <div class="notice-left">
                                <a href="#"><i class="et-line icon-heart"></i>168</a>
                                <span>|</span>
                                <a href="#"><i class="et-line icon-chat"></i>25</a>
                            </div>
                            <div class="notice-right">
                                <a href="18-publication-details.php" target="_blank"><i class="fa fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="single-notice notice2">
                        <h3><a href="18-publication-details.php" target="_blank">Our Kindergarten Anniversary</a></h3>
                        <p class="credit">By <span>Lara croft</span>, Jan 21st 2017</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                        <div class="notice-comment flex space-between">
                            <div class="notice-left">
                                <a href="#"><i class="et-line icon-heart"></i>168</a>
                                <span>|</span>
                                <a href="#"><i class="et-line icon-chat"></i>25</a>
                            </div>
                            <div class="notice-right">
                                <a href="18-publication-details.php" target="_blank"><i class="fa fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="single-notice notice3">
                        <h3><a href="18-publication-details.php" target="_blank">How Kids make sense of Life</a></h3>
                        <p class="credit">By <span>Lara croft</span>, Jan 21st 2017</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                        <div class="notice-comment flex space-between">
                            <div class="notice-left">
                                <a href="#"><i class="et-line icon-heart"></i>168</a>
                                <span>|</span>
                                <a href="#"><i class="et-line icon-chat"></i>25</a>
                            </div>
                            <div class="notice-right">
                                <a href="18-publication-details.php" target="_blank"><i class="fa fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="single-notice notice4">
                        <h3><a href="18-publication-details.php" target="_blank">New intake</a></h3>
                        <p class="credit">By <span>Lara croft</span>, Jan 21st 2017</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                        <div class="notice-comment flex space-between">
                            <div class="notice-left">
                                <a href="18-publication-details.php" target="_blank"><i class="et-line icon-heart"></i>168</a>
                                <span>|</span>
                                <a href="18-publication-details.php" target="_blank"><i class="et-line icon-chat"></i>25</a>
                            </div>
                            <div class="notice-right">
                                <a href="18-publication-details.php" target="_blank"><i class="fa fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="single-notice notice5">
                        <h3><a href="18-publication-details.php" target="_blank">New intake</a></h3>
                        <p class="credit">By <span>Lara croft</span>, Jan 21st 2017</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                        <div class="notice-comment flex space-between">
                            <div class="notice-left">
                                <a href="#"><i class="et-line icon-heart"></i>168</a>
                                <span>|</span>
                                <a href="#"><i class="et-line icon-chat"></i>25</a>
                            </div>
                            <div class="notice-right">
                                <a href="18-publication-details.php" target="_blank"><i class="fa fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="single-notice notice6">
                        <h3><a href="18-publication-details.php" target="_blank">How Kids make sense of Life</a></h3>
                        <p class="credit">By <span>Lara croft</span>, Jan 21st 2017</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                        <div class="notice-comment flex space-between">
                            <div class="notice-left">
                                <a href="#"><i class="et-line icon-heart"></i>168</a>
                                <span>|</span>
                                <a href="#"><i class="et-line icon-chat"></i>25</a>
                            </div>
                            <div class="notice-right">
                                <a href="18-publication-details.php" target="_blank"><i class="fa fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Notice Board End -->
<section class="cta-1 kindergarten-cta">
    <div class="cta-bg4 relative"  data-velocity=".2">
        <div class="overlay cta-overlay-bg4"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="cta-content">
                        <h2>We are going to a picnic this easter!</h2>
                        <div class="picnic-countdown">
                            <div class="countdown flex" id="js-countdown">
                                <div class="countdown__item">
                                    <div class="countdown__timer js-countdown-days days common" aria-labelledby="day-countdown">

                                    </div>

                                    <div class="countdown__label title" id="day-countdown">Days</div>
                                </div>

                                <div class="countdown__item">
                                    <div class="countdown__timer hours common js-countdown-hours" aria-labelledby="hour-countdown">

                                    </div>

                                    <div class="countdown__label title" id="hour-countdown">Hours</div>
                                </div>

                                <div class="countdown__item">
                                    <div class="countdown__timer minutes common js-countdown-minutes" aria-labelledby="minute-countdown">

                                    </div>

                                    <div class="countdown__label title" id="minute-countdown">Minutes</div>
                                </div>

                                <div class="countdown__item">
                                    <div class="countdown__timer seconds common js-countdown-seconds" aria-labelledby="second-countdown">

                                    </div>

                                    <div class="countdown__label title" id="second-countdown">Seconds</div>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="btn">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Area Start -->
<section class="section-full kindergarten-testimonial">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="active-test-carousel">
                    <div class="single-carousel">
                        <div class="single-testimonial test1">
                            <div class="icon">
                                <span class="et-line  icon-quote"></span>
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Father of pre school student</span>
                            </div>
                        </div>
                    </div>
                    <div class="single-carousel">
                        <div class="single-testimonial test2">
                            <div class="icon">
                                <span class="et-line  icon-quote"></span>
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Father of pre school student</span>
                            </div>
                        </div>
                    </div>
                    <div class="single-carousel">
                        <div class="single-testimonial test1">
                            <div class="icon">
                                <span class="et-line  icon-quote"></span>
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Father of pre school student</span>
                            </div>
                        </div>
                    </div>
                    <div class="single-carousel">
                        <div class="single-testimonial test2">
                            <div class="icon">
                                <span class="et-line  icon-quote"></span>
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Father of pre school student</span>
                            </div>
                        </div>
                    </div>
                    <div class="single-carousel">
                        <div class="single-testimonial test1">
                            <div class="icon">
                                <span class="et-line  icon-quote"></span>
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Father of pre school student</span>
                            </div>
                        </div>
                    </div>
                    <div class="single-carousel">
                        <div class="single-testimonial test2">
                            <div class="icon">
                                <span class="et-line  icon-quote"></span>
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Father of pre school student</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Area End -->
</main>
<!-- Footer Area Start -->
<footer id="footer1" class="bg-gray">
    <div class="kindergarten-footer">
        <div class="container">
            <div class="row">
                <div class="footer-widget">
                    <div class="col-md-3 col-sm-6 col-xs-12 tb-height">
                        <div class="footer-widget-address">
                            <img src="img/footer/1.jpg" alt="" class="img-responsive">
                            <ul class="footer-address">
                                <li><span class="et-line icon-map-pin"></span>56/8, West panthapath,India.</li>
                                <li><span class="et-line icon-mic"></span> +00 91 234 567 890</li>
                                <li><span class="et-line icon-global"></span>www.educare.com</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 tb-height">
                        <div class="footer-widget-link widget1">
                            <h4 class="second-title">Useful Links</h4>
                            <div class="row">
                                <div class="col-sm-4">
                                    <ul>
                                        <li><a href="09-about.php" target="_blank">About Us</a></li>
                                        <li><a href="32-blog-home.php" target="_blank">Blog</a></li>
                                        <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                        <li><a href="11-course-grid-02.php" target="_blank">Courses</a></li>
                                        <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                        <li><a href="15-events-listview.php" target="_blank">Events</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-8">
                                    <ul>
                                        <li><a href="#">Become a Teacher</a></li>
                                        <li><a href="#">Maintenance</a></li>
                                        <li><a href="#">Language Packs</a></li>
                                        <li><a href="#">LearnPress</a></li>
                                        <li><a href="#">Release Status</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 tb-height">
                        <div class="footer-widget-course widget2">
                            <h4 class="second-title">Recent Courses</h4>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/4.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Dance Class</a></h4>
                                    <span>$20/Day</span>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/5.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Music Class</a></h4>
                                    <span>$25/Day</span>
                                </div>
                            </div>
                            <div class="media single-widget-course">
                                <div class="media-left">
                                    <a href="14-course-details.php" target="_blank">
                                        <img class="media-object" src="img/footer/6.jpg" alt="">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Drawing Class</a></h4>
                                    <span>$30/Day</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 tb-height">
                        <div class="footer-widget-contact widget3">
                            <h4 class="second-title">Send Message</h4>
                            <form action="#">
                                <p><input placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" type="text" required></p>
                                <p><input placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" required></p>
                                <p><textarea cols="30" rows="10" placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" required></textarea></p>
                                <p><button class="btn submit-btn">Send</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="footer-social-link">
                        <ul class="flex flex-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-bottom-text">
                        <p>Copyright &amp;copy 2017. Designed by <a href="#">Codepixar Studio</a>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>
</html>