<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>Educare</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body><header id="header1" class="blue-bg default-header header6 header7">
    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-md-7">
                    <ul class="top-left flex">
                        <li class="flex pr-60">
                            <i class="fa fa-language" aria-hidden="true"></i>
                            <div class="select-ct">
                                <select>
                                    <option value="1">English</option>
                                    <option value="2">Bangla</option>
                                    <option value="3">Hindi</option>
                                    <option value="4">Chinese</option>
                                </select>
                            </div>
                        </li>
                        <li class="pr-60"> 
                            <a href="mailto:info@educare.com"><i class="fa fa-envelope-o" aria-hidden="true"></i>info@educare.com</a>
                        </li>
                        <li class="pr-60">
                            <a href="tel:+1386-263-3623"><i class="fa fa-phone" aria-hidden="true"></i>+1386-263-3623</a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-5">
                    <ul class="top-right flex flex-right">
                        <li class="pl-60">
                            <a href="21-login.php"><i class="fa fa-user" aria-hidden="true"></i>Login</a>
                        </li>
                        <li class="pl-60">
                            <a href="21-login-register.php"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Register</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="navbar-area flex space-between">
            <div class="left-bar">
                <div class="logo">
                    <a href="#">
                        <img src="img/logo/logo2.png" alt="">
                    </a>
                </div>
            </div>
            <div class="right-bar flex">
                <nav>
                    <ul id="mobile" class="main-menu  hidden-xs">
                        <li class="my-active"><a href="#">Home</a>
                            <ul class="sub-menu">
                                <li><a href="index.php" target="_blank">Home University</a></li>
                                <li><a href="02-home-college.php" target="_blank">Home College</a></li>
                                <li><a href="03-home-online-education.php" target="_blank">Home Online Education</a></li>
                                <li><a href="04-home-language.php" target="_blank">Home Language</a></li>
                                <li><a href="05-home-kindergarten.php" target="_blank">Home Kindergarten</a></li>
                                <li><a href="06-home-driving-school.php" target="_blank">Home Driving School</a></li>
                                <li><a href="07-home-designing-school.php" target="_blank">Home Designing School</a></li>
                                <li><a href="08-home-cooking-school.php" target="_blank">Home Cooking School</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Courses</a>
                            <ul class="sub-menu">
                                <li><a href="10-course-grid-01.php" target="_blank">Course Grid 01</a></li>
                                <li><a href="11-course-grid-02.php" target="_blank">Course Grid 02</a></li>
                                <li><a href="12-course-list-01.php" target="_blank">Course List 01</a></li>
                                <li><a href="13-course-list-02.php" target="_blank">Course List 02</a></li>
                                <li><a href="14-course-details.php" target="_blank">Course Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Teacher</a>
                            <ul class="sub-menu">
                                <li><a href="26-teacher-grid.php" target="_blank">Teacher Grid</a></li>
                                <li><a href="27-teacher-list.php" target="_blank">Teacher List</a></li>
                                <li><a href="28-teacher-archive.php" target="_blank">Teacher Archive</a></li>
                                <li><a href="29-teacher-details.php" target="_blank">Teacher Details</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="32-blog-home.php" target="_blank">blog home</a></li>
                                <li><a href="33-blog-left-sidebar.php" target="_blank">blog Left sidebar</a></li>
                                <li><a href="34-blog-right-sidebar.php" target="_blank">blog right sidebar</a></li>
                                <li><a href="35-blog-single.php" target="_blank">blog single</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Events</a>
                            <ul class="sub-menu">
                                <li><a href="15-events-listview.php" target="_blank">Events list view</a></li>
                                <li><a href="16-events-gridview.php" target="_blank">Events grid view</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Shop</a>
                            <ul class="sub-menu">
                                <li><a href="36-shop-home.php" target="_blank">shop home</a></li>
                                <li><a href="37-shop-grid-sidebar.php" target="_blank">shop grid sidebar</a></li>
                                <li><a href="38-shop-list-sidebar.php" target="_blank">shop list sidebar</a></li>
                                <li><a href="39-shop-single-product.php" target="_blank">shop single product</a></li>
                                <li><a href="40-shop-cart.php" target="_blank">shop cart</a></li>
                                <li><a href="41-shop-checkout.php" target="_blank">shop checkout</a></li>
                                <li><a href="42-shop-payment.php" target="_blank">shop Payment</a></li>
                                <li><a href="43-shop-confirmation.php" target="_blank">shop Confirmation</a></li>
                            </ul>
                        </li>
                        <li><a href="#">buddypress</a>
                            <ul class="sub-menu">
                                <li><a href="44-buddypress-activity.php" target="_blank">Buddypress activity</a></li>
                                <li><a href="44-buddypress-activity-afterlogin.php" target="_blank">Buddypress activity afterLogin</a></li>
                                <li><a href="46-buddypress-members.php" target="_blank">Buddypress member</a></li>
                                <li><a href="45-buddypress-groups.php" target="_blank">Buddypress group</a></li>
                                <li><a href="48-buddypress-groupdetails-afterlogin.php" target="_blank">Buddypress group afterLogin</a></li>
                                <li><a href="49-buddypress-forums-home.php" target="_blank">Buddypress forums home</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="50-elements.php" target="_blank">Elements</a></li>
                                <li><a href="09-about.php" target="_blank">About Educare</a></li>
                                <li><a href="17-publication-board.php" target="_blank">publication board</a></li>
                                <li><a href="18-publication-details.php" target="_blank">publication details</a></li>
                                <li><a href="19-testimonials.php" target="_blank">testimonials</a></li>
                                <li><a href="20-clients.php" target="_blank">clients</a></li>
                                <li><a href="21-login-register.php" target="_blank">login / register</a></li>
                                <li><a href="22-department-grid.php" target="_blank">department grid</a></li>
                                <li><a href="23-department-list.php" target="_blank">depatment list</a></li>
                                <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                <li><a href="30-404-error.php" target="_blank">404 Error</a></li>
                                <li><a href="31-comming-soon.php" target="_blank">Comming soon</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main class="home-designing">
<section id="slider" class="slider-section relative mobile-none">
    <div class="slider1 deafult-slider slider7">
        <div class="item active relative  fullscreen flex flex-middle" style="background: url(img/slider/10.jpg);">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <div class="slide-content">
                            <h1 class="light h1">Learn to Master your Designing Skills with Educare Designing School</h1>
                            <p class="light mt-10">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="10-course-grid-01.php" target="_blank" class="btn mt-10 mr-10">Start Now</a>
                            <a href="09-about.php" target="_blank" class="btn mt-10">Read More</a>
                        </div>
                    </div>
                    <div class="col-md-offset-1 col-md-4 col-sm-5 col-xs-12">
                        <div class="slider-register">
                            <div class="register-head">
                                <h4>Available Design Courses</h4>
                                <h6>Register Now</h6>
                            </div>
                            <form action="#">
                                <p><input placeholder="Your Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" type="text"></p>
                                <p><input placeholder="Your Phone Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Phone Number'" type="text"></p>
                                <p><input placeholder="Your Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address'" type="email"></p>
                                <p class="select-ct">
                                    <select>
                                        <option value="1">Choose Course</option>
                                        <option value="2">Choose Course</option>
                                        <option value="3">Choose Course</option>
                                        <option value="4">Choose Course</option>
                                    </select>
                                </p>
                                <p><button class="btn submit-btn">Submit</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item relative  fullscreen flex flex-middle" style="background: url(img/slider/11.jpg);">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <div class="slide-content mt-100">
                            <h1 class="light h1">Brainstorming is the best habit to create new ideas</h1>
                            <p class="light mt-10">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="10-course-grid-01.php" target="_blank" class="btn mt-10 mr-10">Start Now</a>
                            <a href="09-about.php" target="_blank" class="btn mt-10">Read More</a>
                        </div>
                    </div>
                    <div class="col-md-offset-1 col-md-4 col-sm-5 col-xs-12">
                        <div class="slider-register">
                            <div class="register-head">
                                <h4>Available Design Courses</h4>
                                <h6>Register Now</h6>
                            </div>
                            <form action="#">
                                <p><input placeholder="Your Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" type="text"></p>
                                <p><input placeholder="Your Phone Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Phone Number'" type="text"></p>
                                <p><input placeholder="Your Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address'" type="email"></p>
                                <p class="select-ct">
                                    <select>
                                        <option value="1">Choose Course</option>
                                        <option value="2">Choose Course</option>
                                        <option value="3">Choose Course</option>
                                        <option value="4">Choose Course</option>
                                    </select>
                                </p>
                                <p><button class="btn submit-btn">Submit</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item relative  fullscreen flex flex-middle" style="background: url(img/slider/12.jpg);">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-7 col-xs-12">
                        <div class="slide-content mt-100">
                            <h1 class="light h1">Comparing with other designers is perfect practice to learn</h1>
                            <p class="light mt-10">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="10-course-grid-01.php" target="_blank" class="btn mt-10 mr-10">Start Now</a>
                            <a href="09-about.php" target="_blank" class="btn mt-10">Read More</a>
                        </div>
                    </div>
                    <div class="col-sm-offset-1 col-sm-4 col-xs-12">
                        <div class="slider-register">
                            <div class="register-head">
                                <h4>Available Design Courses</h4>
                                <h6>Register Now</h6>
                            </div>
                            <form action="#">
                                <p><input placeholder="Your Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" type="text"></p>
                                <p><input placeholder="Your Phone Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Phone Number'" type="text"></p>
                                <p><input placeholder="Your Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address'" type="email"></p>
                                <p class="select-ct">
                                    <select>
                                        <option value="1">Choose Course</option>
                                        <option value="2">Choose Course</option>
                                        <option value="3">Choose Course</option>
                                        <option value="4">Choose Course</option>
                                    </select>
                                </p>
                                <p><button class="btn submit-btn">Submit</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="slider-section relative">
    <div class="deafult-slider mobile-banner slider7">
        <div class="item relative" style="background: url(img/slider/10.jpg);">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <div class="slide-content">
                            <h1 class="light h1">Learn to Master your Designing Skills with Educare Designing School</h1>
                            <p class="light mt-10">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <a href="10-course-grid-01.php" target="_blank" class="btn mt-10 mr-10">Start Now</a>
                            <a href="09-about.php" target="_blank" class="btn mt-10">Read More</a>
                        </div>
                    </div>
                    <div class="col-md-offset-1 col-md-4 col-sm-5 col-xs-12">
                        <div class="slider-register">
                            <div class="register-head">
                                <h4>Available Design Courses</h4>
                                <h6>Register Now</h6>
                            </div>
                            <form action="#">
                                <p><input placeholder="Your Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Name'" type="text"></p>
                                <p><input placeholder="Your Phone Number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Phone Number'" type="text"></p>
                                <p><input placeholder="Your Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address'" type="email"></p>
                                <p class="select-ct">
                                    <select>
                                        <option value="1">Choose Course</option>
                                        <option value="2">Choose Course2</option>
                                        <option value="3">Choose Course3</option>
                                        <option value="4">Choose Course4</option>
                                    </select>
                                </p>
                                <p><button class="btn submit-btn">Submit</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Advanced Search Area Start -->
<div class="advance-search-area designing-search">
    <div class="container ">
        <div class="row">
            <div class="advance-search">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="select-ct">
                        <select name="course-list">
                            <option value="7">Choose Level</option>
                            <option value="1">Adobe Illustrator</option>
                            <option value="2">Adobe After Effects</option>
                            <option value="3">Adobe Muse</option>
                            <option value="4">Adobe Photoshop</option>
                            <option value="5">Adobe Premier pro</option>
                            <option value="6">Adobe Indesign</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="select-ct">
                        <select name="course-list">
                            <option value="7">Choose Category</option>
                            <option value="1">Adobe Illustrator</option>
                            <option value="2">Adobe After Effects</option>
                            <option value="3">Adobe Muse</option>
                            <option value="4">Adobe Photoshop</option>
                            <option value="5">Adobe Premier pro</option>
                            <option value="6">Adobe Indesign</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="select-ct">
                        <select name="course-list">
                            <option value="" class="option">Choose Type</option>
                            <option value="1">Adobe Illustrator</option>
                            <option value="2">Adobe After Effects</option>
                            <option value="3">Adobe Muse</option>
                            <option value="4">Adobe Photoshop</option>
                            <option value="5">Adobe Premier pro</option>
                            <option value="6">Adobe Indesign</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single-search-btn">
                        <a href="#" class="btn">Search Course</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Advanced Search Area End -->
<!-- Steering Area Start -->
<div class="steering-area section-full">
    <div class="container">
        <div class="row">
            <div class="steering">
                <div class="steering-vector">
                    <div class="design1">
                        <div class="design2">
                            <div class="circle-box">
                                <div class="single-circle circle1"></div>
                                <div class="single-circle circle2"></div>
                                <div class="single-circle circle3"></div>
                                <div class="single-circle circle4"></div>
                                <div class="single-circle circle5"></div>
                                <div class="single-circle circle6"></div>
                                <div class="single-circle circle7"></div>
                            </div>
                        </div>
                        <h3 class="steering-head head1">01. Determination</h3>
                        <h3 class="steering-head head2">02. Knowing Designing Tools</h3>
                        <h3 class="steering-head head3">03. Being expert on Tools</h3>
                        <h3 class="steering-head head4">04. Following good Designs</h3>
                        <h3 class="steering-head head5">05. Start Creating Ideas</h3>
                        <h3 class="steering-head head6">06. Mastering Creativity</h3>
                    </div>
                </div>
                <div class="mobile-steering">
                    <h3>01. Determination</h3>
                    <h3>02. Knowing Designing Tools</h3>
                    <h3>03. Being expert on Tools</h3>
                    <img src="img/vector/mb7.png" alt="" class="img-responsive">
                    <h3>04. Following good Designs</h3>
                    <h3>05. Start Creating Ideas</h3>
                    <h3>06. Mastering Creativity</h3>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Steering Area End -->
<!-- Regular Course Start -->
<section class="section-full course-grid1 bg-gray regular-course7">
    <div class="container">
        <div class="popular-course">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head text-center pb-50">
                        <h2 class="first-title">Regular Courses</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adippisicing
                        elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="popular-course-body">
                <div class="col-sm-4">
                    <div class="single-popular">
                        <img src="img/course/r1.jpg" class="img-responsive" alt="">
                        <div class="grid-course">
                            <div class="popular-course-content p-40">
                                <h3><a href="14-course-details.php" target="_blank">Photography Course</a></h3>
                                <p class="reviews pt-20">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <span class="review-count">20 Reviews</span>
                                </p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                                <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                            </div>
                            <div class="course-bottom flex">
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom amount">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="single-popular">
                        <img src="img/course/r2.jpg" class="img-responsive" alt="">
                        <div class="grid-course">
                            <div class="popular-course-content p-40">
                                <h3><a href="14-course-details.php" target="_blank">Web Design Course</a></h3>
                                <p class="reviews pt-20">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <span class="review-count">20 Reviews</span>
                                </p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                                <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                            </div>
                            <div class="course-bottom flex">
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom amount">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="single-popular">
                        <img src="img/course/r3.jpg" class="img-responsive" alt="">
                        <div class="grid-course">
                            <div class="popular-course-content p-40">
                                <h3><a href="14-course-details.php" target="_blank">UI/UX Design Course</a></h3>
                                <p class="reviews pt-20">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <span class="review-count">20 Reviews</span>
                                </p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                                <a href="14-course-details.php" target="_blank" class="learn">Learn More  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                            </div>
                            <div class="course-bottom flex">
                                <div class="single-bottom trainer">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span><span>Tim Mathews</span></a>
                                </div>
                                <div class="single-bottom">
                                    <span>Total 15 Seats</span>
                                </div>
                                <div class="single-bottom amount">
                                    <span>$150</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / #Regular Course End -->
<!-- Trainer Area Start -->
<section id="chose-teachers" class="section-full expert-trainer">
    <div class="container">
        <div class="chose-course">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head text-center pb-70">
                        <h2 class="first-title">Our Trainers</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adippisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="total-trainer">
                    <div class="col-sm-6">
                        <div class="single-trainer">
                            <div class=" row">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/1.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.php" target="_blank">Ashley Collins</a></h4>
                                        <p class="mt-10 mb-10">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.php" target="_blank" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="single-trainer">
                            <div class=" row">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/2.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.php" target="_blank">Karma Reddy</a></h4>
                                        <p class="mt-10 mb-10">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.php" target="_blank" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="single-trainer">
                            <div class=" row">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/3.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.php" target="_blank">Victor Valdez</a></h4>
                                        <p class="mt-10 mb-10">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.php" target="_blank" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="single-trainer">
                            <div class=" row">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/4.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.php" target="_blank">Solomon Allot</a></h4>
                                        <p class="mt-10 mb-10">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.php" target="_blank" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / #Trainer Area End  -->
<!-- CTA Start -->
<section class="cta-7">
    <div class="cta-bg7 relative">
        <div class="overlay cta-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="cta-content">
                    <div class="col-sm-6 col-xs-12">
                        <div class="single-cta first-cta">
                            <span class="et-line icon-hazardous"></span>
                            <h3><a href="#">Free Call Support</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <div class="single-cta last-cta">
                            <span class="et-line icon-pricetags"></span>
                            <h3><a href="#">The Best Discount</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- CTA End -->
<!-- Testimonial Area Start -->
<section class="section-full designing-testimonial">
    <div class="container">
        <div class="row">
            <div class="active-design-carousel">
                <div class="single-carousel">
                    <div class="col-sm-offset-2 col-sm-8">
                        <div class="single-testimonial">
                            <div class="test-img">
                                <img src="img/testimonial/t3.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Adobe Indesign</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-carousel">
                    <div class="col-sm-offset-2 col-sm-8">
                        <div class="single-testimonial">
                            <div class="test-img">
                                <img src="img/testimonial/t3.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Adobe Indesign</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-carousel">
                    <div class="col-sm-offset-2 col-sm-8">
                        <div class="single-testimonial">
                            <div class="test-img">
                                <img src="img/testimonial/t3.jpg" alt="" class="img-responsive">
                            </div>
                            <div class="test-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat.</p>
                                <h4>Lara Croft Johnson</h4>
                                <span>Adobe Indesign</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Area End -->
<!-- Blog Area Start -->
<section id="blog" class="section-full bg-gray">
    <div class="container">
        <div class="blog">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-offset-10">
                    <div class="section-head text-center pb-100">
                        <h2 class="first-title">Recent Blog Posts</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adippisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="total-blog">
                    <div class="col-sm-4 col-xs-12">
                        <div class="single-blog1">
                            <img src="img/blog/1.jpg" alt="" class="img-responsive">
                            <div class="blog-content">
                                <span class="date">2nd Feb 2017</span>
                                <h4 class="blog-head"><a href="35-blog-single.php" target="_blank">Drive your own Car</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                <p><a href="35-blog-single.php" target="_blank">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                <div class="blog-comment flex space-between">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span> Lendl Simmons</a>
                                    <a href="#"><span class="et-line icon-chat"></span>09 Comments</a>
                                </div>
                            </div>
                        </div>
                        <div class="single-blog2">
                            <div class="bg-gray total-link">
                                <p><span class="et-line icon-attachment"></span></p>
                                <h4 class="blog-head"><a href="35-blog-single.php" target="_blank">Drive your own Car</a></h4>
                                <div class="blog-comment flex space-between">
                                    <a href="29-teacher-details.php" target="_blank" class="s-comment"><span class="et-line icon-profile-male"></span> Lendl Simmons</a>
                                    <a href="#" class="s-comment"><span class="et-line icon-chat"></span>09 Comments</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="single-blog3">
                            <div class="bg-gray total-link">
                                <p><a href="35-blog-single.php" target="_blank">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</a></p>
                                <p class="icon"><span class="et-line icon-quote text-black"></span></p>
                                <p class="name"><a href="29-teacher-details.php" target="_blank">Bubalo Smith</a></p>
                            </div>
                        </div>
                        <div class="single-blog4">
                            <div class="total-link">
                                <div class="overlay op-2"></div>
                                <div class="total-content">
                                    <span>2nd Feb 2017</span>
                                    <h4 class="blog-head"><a href="35-blog-single.php" target="_blank">Drive your own Car</a></h4>
                                    <div class="blog-comment flex space-between">
                                        <a href="29-teacher-details.php" target="_blank" class="s-comment"><span class="et-line icon-profile-male"></span> Lendl Simmons</a>
                                        <a href="#" class="s-comment"><span class="et-line icon-chat"></span>09 Comments</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="single-blog1">
                            <img src="img/blog/2.jpg" alt="" class="img-responsive">
                            <div class="blog-content">
                                <span class="date">2nd Feb 2017</span>
                                <h4 class="blog-head"><a href="35-blog-single.php" target="_blank">Drive your own Car</a></h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                <p><a href="35-blog-single.php" target="_blank">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                <div class="blog-comment flex space-between">
                                    <a href="29-teacher-details.php" target="_blank"><span class="et-line icon-profile-male"></span> Lendl Simmons</a>
                                    <a href="#"><span class="et-line icon-chat"></span>09 Comments</a>
                                </div>
                            </div>
                        </div>
                        <div class="single-blog5">
                            <div class="overlay overlay-bg"></div>
                            <div class="total-link">
                                <p><span class="et-line icon-attachment"></span></p>
                                <h4 class="blog-head"><a href="35-blog-single.php" target="_blank">Drive your own Car</a></h4>
                                <div class="blog-comment flex space-between">
                                    <a href="29-teacher-details.php" target="_blank" class="s-comment"><span class="et-line icon-profile-male"></span> Lendl Simmons</a>
                                    <a href="#" class="s-comment"><span class="et-line icon-chat"></span>09 Comments</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / #Blog Area End  -->
<div class="container-fluid">
<div class="container icons">
    <div class="row" id="demo">
        <div class="brand">
            <div class="item"><img src="img/brand/1.png" alt="icon-1"/></div>
            <div class="item"><img src="img/brand/2.png" alt="icon-1"/></div>
            <div class="item"><img src="img/brand/3.png" alt="icon-1"/></div>
            <div class="item"><img src="img/brand/4.png" alt="icon-1"/></div>
            <div class="item"><img src="img/brand/5.png" alt="icon-1"/></div>
            <div class="item"><img src="img/brand/6.png" alt="icon-1"/></div>
        </div>
    </div>
</div>
</div>
</main>
<!-- Footer Area Start -->
<footer id="footer1" class="bg-blue">
    <div class="footer2 footer7">
        <div class="container">
            <div class="row">
                <div class="footer-widget">
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-address">
                            <img src="img/footer/1.jpg" alt="" class="img-responsive">
                            <ul class="footer-address">
                                <li><span class="et-line icon-map-pin"></span>56/8, West panthapath,India.</li>
                                <li><span class="et-line icon-mic"></span> +00 91 234 567 890</li>
                                <li><span class="et-line icon-global"></span>www.educare.com</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-link">
                            <h4 class="second-title">Useful Links</h4>
                            <div class="row">
                                <div class="col-sm-4">
                                    <ul>
                                        <li><a href="09-about.php" target="_blank">About Us</a></li>
                                        <li><a href="32-blog-home.php" target="_blank">Blog</a></li>
                                        <li><a href="25-contact.php" target="_blank">Contact</a></li>
                                        <li><a href="11-course-grid-02.php" target="_blank">Courses</a></li>
                                        <li><a href="24-faqs.php" target="_blank">FAQS</a></li>
                                        <li><a href="15-events-listview.php" target="_blank">Events</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-8">
                                    <ul>
                                        <li><a href="#">Become a Teacher</a></li>
                                        <li><a href="#">Maintenance</a></li>
                                        <li><a href="#">Language Packs</a></li>
                                        <li><a href="#">LearnPress</a></li>
                                        <li><a href="#">Release Status</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-course">
                        <h4 class="second-title">Recent Courses</h4>
                        <div class="media single-widget-course">
                            <div class="media-left">
                                <a href="14-course-details.php" target="_blank">
                                    <img class="media-object" src="img/footer/2.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Graphic Design Course</a></h4>
                                <p class="reviews">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <span>20 Reviews</span>
                                </p>
                            </div>
                        </div>
                        <div class="media single-widget-course">
                            <div class="media-left">
                                <a href="14-course-details.php" target="_blank">
                                    <img class="media-object" src="img/footer/3.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.php" target="_blank">Adobe sketch Course</a></h4>
                                <p class="reviews">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <span>35 Reviews</span>
                                </p>
                            </div>
                        </div>
                        <div class="media single-widget-course">
                            <div class="media-left">
                                <a href="14-course-details.php" target="_blank">
                                    <img class="media-object" src="img/footer/2.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.php" target="_blank"> Adobe Indesign Course</a></h4>
                                <p class="reviews">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <span>35 Reviews</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                        <div class="footer-widget-contact">
                            <h4 class="second-title">Send Message</h4>
                            <form action="#">
                                <p><input placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" type="text" required></p>
                                <p><input placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" required></p>
                                <p><textarea cols="30" rows="10" placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" required></textarea></p>
                                <p><button class="btn submit-btn">Send</button></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="footer-social-link">
                        <ul class="flex flex-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        </ul>
                    </div>
                    <div class="footer-bottom-text">
                        <p>Copyright &amp;copy 2017. Designed by <a href="#">Codepixar Studio</a>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>
</html>